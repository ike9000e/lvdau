#include "dfh_cma_average.hh"
#include <cmath>   
#include <limits>  
#include <cinttypes>  
#include <cassert>  


template<class Tvx>
DfhCMAAverage2<Tvx>::DfhCMAAverage2()
{
	if( !mAllowedRange.second ){
		mAllowedRange = getAllowedMinMax9();
	}
}
template<class Tvx>
const std::pair<Tvx,Tvx>&
DfhCMAAverage2<Tvx>::getAllowedMinMax()  
{
	if( !mAllowedRange.second ){
		mAllowedRange = getAllowedMinMax9();
	}
	return mAllowedRange;
}
#ifdef _MSC_VER
	#pragma warning ( push )   
	#pragma warning ( disable: 4244 )  
	#pragma warning ( disable: 4146 )  
#endif
template<class Tvx>
std::pair<Tvx,Tvx>
DfhCMAAverage2<Tvx>::getAllowedMinMax9()  
{
	std::pair<Tvx,Tvx> aMinMax;
	Tvx vHalfOfMax = ( std::numeric_limits<Tvx>::max() / 2 );
	if( std::is_signed<Tvx>::value ){
		aMinMax = { -vHalfOfMax, vHalfOfMax,};
	}else{
		aMinMax = { Tvx{0}, vHalfOfMax,};
	}
	return aMinMax;
}

template<class Tvx>
std::pair<Tvx,Tvx> DfhCMAAverage2<Tvx>::mAllowedRange = { 0, 0,};
#ifdef _MSC_VER
	#pragma warning ( pop )   
#endif

template<class Tvx>
Tvx DfhCMAAverage2<Tvx>::getAvg()const
{
	if( !mIsValid3 ){
		if( std::is_floating_point<Tvx>::value ){
			return static_cast<Tvx>( std::nan("") ); //NAN
		}else{
			return 0;
		}
	}
	return mAvg2;
}
template<class Tvx>
DfhCMAAverage2<Tvx>&
DfhCMAAverage2<Tvx>::setAvg( Tvx inp )
{
	mAvg2 = inp;
	return *this;
}
template<class Tvx>
DfhCMAAverage2<Tvx>&
DfhCMAAverage2<Tvx>::update2( Tvx inp )
{
	if( !mIsValid3 || inp < mAllowedRange.first || inp > mAllowedRange.second ){
		mIsValid3 = 0L;
		return *this;
	}
	update9( inp );
	return *this;
}

template<class Tvx>
template< typename Txx, typename std::enable_if< std::is_floating_point<Txx>::value,int>::type Tdummy >
DfhCMAAverage2<Tvx>&
DfhCMAAverage2<Tvx>::update9( Tvx inp )
{
	mCount += 1;
	Tvx numerator2 = inp - mAvg2;
	mAvg2 += numerator2 / mCount;
	
	
	return *this;
}

template<class Tvx>
template< typename Txx, typename std::enable_if< ! std::is_floating_point<Txx>::value,int>::type Tdummy >
DfhCMAAverage2<Tvx>&
DfhCMAAverage2<Tvx>::update9( Tvx inp )
{
	mCount += 1;
	Tvx numerator3 = inp - mAvg2 + mCumulatedRemainder;
	mAvg2 += numerator3 / mCount;
	mCumulatedRemainder = numerator3 % mCount;
	return *this;
}
template<class Tvx>
size_t DfhCMAAverage2<Tvx>::getDigitsCount()
{
	
	
	
	
	
	
	size_t nNumDigits = std::numeric_limits<Tvx>::digits;
	if( !std::is_floating_point<Tvx>::value ){
		nNumDigits -= 1;
	}
	return nNumDigits;
}


template struct DfhCMAAverage2<float>;
template struct DfhCMAAverage2<double>;
template struct DfhCMAAverage2<long double>;
template struct DfhCMAAverage2<int8_t>;
template struct DfhCMAAverage2<uint8_t>;
template struct DfhCMAAverage2<int16_t>;
template struct DfhCMAAverage2<uint16_t>;
template struct DfhCMAAverage2<int32_t>;
template struct DfhCMAAverage2<uint32_t>;
template struct DfhCMAAverage2<int64_t>;
template struct DfhCMAAverage2<uint64_t>;

void DfhUnitTests4()
{
	{
		DfhCMAAverage2<uint64_t> avg2;
		avg2.update2( 0xFFFFFFFF );
		avg2.update2( 0xFFFFFFFF );
		avg2.update2( 0xFFFFFFFF );
		avg2.update2( 0xFFFFFFFF );
		
		assert( avg2.getAvg() == 0xFFFFFFFF );
	}{
		DfhCMAAverage2<uint64_t> avg3;
		const auto minmax2 = avg3.getAllowedMinMax();
		avg3.update2( minmax2.second );
		avg3.update2( minmax2.second );
		assert( avg3.getAvg() == minmax2.second );
		;
	}{
		DfhCMAAverage2<int32_t> avg2;
		avg2.update2( 1000000000 );
		avg2.update2( 0 );
		avg2.update2( 999999999 );
		avg2.update2( 1 );
		assert( avg2.getAvg() == 500000000 );
	}{
		DfhCMAAverage2<float> avg2;
		avg2.update2( 1.0f );
		avg2.update2( 1.0f );
		avg2.update2( 0.0f );
		avg2.update2( 0.0f );
		avg2.update2( 0.3f );
		avg2.update2( 0.7f );
		assert( (std::fabs( 0.5f - avg2.getAvg() )) <= std::numeric_limits<float>::epsilon() );
	}
}