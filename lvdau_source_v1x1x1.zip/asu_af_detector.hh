#pragma once
#include <string>
#include <vector>
#include <algorithm>    
#include "asu_intrf.hh"

double   AsuConvSampleS16AbsToFractionF64f2( int16_t nSample2 );
uint32_t AsuConvSampleS16AbsToFractionU32u2( int16_t nSample2 );
double   AsuConvSampleS16ToFracSegmentAligned2( int16_t nSample2, size_t uNumSegments2, bool );

enum AsuUnitAmplifyMode2 : size_t {
	ASU_E7_UnitAmplify_None = 197780901,
	ASU_E7_UnitAmplify_CircleNWQuadrant2,
	ASU_E7_UnitAmplify_QuarterSine,
	ASU_E7_UnitAmplify_SCurveNWSEArcs2,
};
struct AsuSilenceDefinition2 {
	double                fSilenceThresholdFrac2       = 0.2;
	double                fProbeDurationSecs2          = 0.005;
	double                fMinSilenceDurationSecs2     = 0.25;
	AsuUnitAmplifyMode2   eUnitAmpMethod2 = ASU_E7_UnitAmplify_SCurveNWSEArcs2;
	bool                  bKeepShowAllSilences2 = 0L;
	bool                  bOmitLeadingSience2 = 0L;
	bool                  bOmitMiddleSiences2 = 0L;
	bool                  bOmitTrailingSience2 = 0L;
};
enum : size_t {
	ASU_E6_MinSamplesPerProbeSanity2 = 8,
};


struct AsuSilenceDetectorFilter2 : AsuAudioFilterBase2
{
	explicit  AsuSilenceDetectorFilter2( const AsuSilenceDefinition2& );
	;         AsuSilenceDetectorFilter2() = delete;
	bool      AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp )override;
	void      AsuAFiSetFrequency2( size_t )override;
	bool      AsuAFiFinalize2()override;
	auto      AsuAFiGetName2()const -> std::string override {return "Silence_Detector_R2";};
	void      AsuAFiSetAudioReceiver2( AsuReceiverFilterBase2* )override;
	void      setSilenceLogger2( AsuTextLogger6* inp );
private:
	double      calculateCurrentProbeVolume2()const;
	double      calculateProbeVolume2( const std::vector<int16_t>& aProbeValues2 )const;
	double      convFrameSizeToSeconds2( uint64_t uFramePos2 )const;
	void        sendAndClearBuffer2( std::vector<int16_t>*, AsuAudFeedType2 )const;
	std::string getStartEndInSecondsAsString2( double fBegin2, double fEnd2 )const;
	void        addSilenceLogIfNeeded2( const AsuAudioInterval7& );
	void sendAndClearSilence2( std::vector<int16_t>*, uint64_t uStartAtFrame2, uint64_t uEndAtFrame2 );
private:
	AsuSilenceDefinition2    mSilConf2;
	AsuReceiverFilterBase2*  mReceiver2 = nullptr;
	size_t                   mNumFramesPerSec2 = 0;
	size_t                   mNumFramesPerProbe2 = 0;
	std::vector<int16_t>     mProbeBuffer2, mSilenceBuffer2;
	uint64_t                 mCurrFrame2 = 0;
	bool                     mIsInSilenceState2 = 0L;
	uint64_t                 mCurrSilenceStartFrame2 = uint64_t(-1);
	size_t                   mStatMaxSilenceBufSize2 = 0;
	std::vector<AsuAudioInterval7> mDetectedSilences2;
	uint64_t                 mNumSilencesDetected2 = 0;
	DfhQuad2<bool,AsuTextLogger6*> mSilenceLogger2 = { 0L, nullptr,};
};