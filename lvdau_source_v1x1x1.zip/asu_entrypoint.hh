#pragma once
#include <cstdio>   
#include <cstdlib>  
#include <cstring>  
#include <vector>
#include <string>
#include <cassert>  
#include <memory> 
#include "asu_aud_file.hh"
#include "asu_af_detector.hh"
#include "dfh_crt_fix.hh"
#include "dfh_reinterpolate.hh"
#include "asu_aud_out_file.hh"
#include "asu_af_shrinkage.hh"
#include "dfh_cma_average.hh"

struct AsuAppParams2{
	bool            bShowHelp2 = 0L;
	std::string     srInputFn2, srOutpFn2;
	bool            bInfoOnly2 = 0L;  
	bool            bShowBuildInfo2 = 0L;  
	int32_t         bShowProgramParams2 = 0L;  
	bool            bRunUnitTests2 = 1L;
	uint64_t        uNumFramesShow2 = 0; 
	int32_t         nAppLogLevel2 = 4;
	AsuSilenceDefinition2 sSilDef3;
	double          fShrinkFractionTo2 = 0.5;  
	size_t          uMainBufferSize2 = 65536;
	std::array<std::string,2> srSilencesLogFn2;
	AsuWFOParams7   sWfoCfg2;  
	
	static int32_t convLogLevelNameToNumber2( const char* inp );
	std::string    getAppParamsAsString2( const char* szTabs2 )const;
};