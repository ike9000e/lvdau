#include "dfh_core.hh"
#include <cassert>  
#include <cstring>
#include <array>
#include <algorithm>
#include <cmath>  


#ifdef _MSC_VER
	#pragma warning( disable : 4100 )  
	#pragma warning( disable : 4996 )  
	#pragma warning( disable : 4706 )  
#endif

static_assert( sizeof(int32_t) > sizeof(char), "");


std::string DfhHexEncode2( const void* data_, size_t uDataSize, const char* flags2 )
{
	std::string outp;
	DfhHexEncode4( data_, uDataSize, flags2, &outp );
	return outp;
}

std::vector<uint8_t>
DfhHexDecode2( const char* szData2, size_t len2, const char* flags2_u_, std::string* err_ )
{
	len2 = ( len2 != size_t(-1) ? len2 : std::strlen(szData2) );
	std::string sink0, &err2 = ( err_ ? *err_ : sink0 );
	std::vector<uint8_t> outp;
	auto lmbAsciiToNum = []( int32_t chr )->int32_t{
		return ( chr >= 'a' && chr <= 'f' ?
					(chr - 'a') + 10 : (
				chr >= 'A' && chr <= 'F' ?
					(chr - 'A') + 10 : (
				chr >= '0' && chr <= '9' ?
					chr - '0' : (
				-1 ))));
	};
	for( size_t ii2 = 0; ii2 < len2; ){
		if( lmbAsciiToNum( szData2[ii2] ) < 0 ){  
			ii2 += 1;
			continue;
		}
		if( ii2+1 == len2 ){
			err2 = "Unexpected end of the input string [3fflys]";
			break;
		}
		const char ch2 = szData2[ii2+0];
		const char ch3 = szData2[ii2+1];
		const int32_t hi2 = lmbAsciiToNum( ch2 );
		const int32_t lo2 = lmbAsciiToNum( ch3 );
		assert( hi2 >= 0 );
		if( lo2 < 0 ){
			err2 = "Non-hexadec as second character [5qChfJ]";
			break;
		}
		uint32_t uByte = 0;
		uByte += static_cast<uint32_t>( lo2 );
		uByte += static_cast<uint32_t>( hi2 ) * 16;
		assert( uByte <= 255 );
		outp.push_back( static_cast<uint8_t>( uByte ) );
		ii2 += 2;
	}
	outp.shrink_to_fit();
	return outp;
}
std::vector<uint8_t>
DfhHexDecode3( const std::string& data_ )
{
	std::vector<uint8_t> outp;
	outp = DfhHexDecode2( data_.c_str(), data_.size(), "", nullptr );
	return outp;
}
std::string DfhHexEncode3( const std::vector<uint8_t>& inp, const char* flags2 )
{
	std::string outp;
	if( !inp.empty() )
		 outp = DfhHexEncode2( inp.data(), inp.size(), flags2 );
	return outp;
}
void DfhHexEncode4( const void* data_, size_t uDataSize, const char* flags2, std::string* outp )
{
	const bool bSpaceSep = std::strchr( flags2, 's');
	const bool bCommaSep = std::strchr( flags2, 'c');
	char bfr2[16];
	const uint8_t* data2 = reinterpret_cast<const uint8_t*>(data_);
	const uint8_t* endd = data2 + uDataSize;
	for( ; data2 < endd; data2++ ){
		if( data2 > data_ ){   
			if( bSpaceSep ){
				*outp += "\x20";
			}else if( bCommaSep ){
				*outp += ",";
			}
		}
		std::snprintf( bfr2, sizeof(bfr2), "%02X", static_cast<uint32_t>(*data2) );
		*outp += bfr2;
	}
}

size_t DfhStrlenMaxAdvance2( const char* inp, size_t uMaxAdvance2 )
{
	if( uMaxAdvance2 == size_t(-1) ){
		return std::strlen( inp );
	}
	size_t ii2 = 0;
	for( ; ii2 < uMaxAdvance2 && inp[ii2]; ii2++ );;
	return ii2;
}

const char* DfhStrpbrkMaxAdvance2( const char* inp, const char* charset2, size_t uMaxAdvance2 )
{
	if( uMaxAdvance2 == size_t(-1) ){
		return std::strpbrk( inp, charset2 );
	}
	for( size_t ii2 = 0; ii2 < uMaxAdvance2 && inp[ii2]; ii2++ ){
		const char* sz2 = std::strchr( charset2, inp[ii2] );
		if( sz2 ){
			return sz2;
		}
	}
	return nullptr;
}
bool DfhIsAlpha2( char ch2 )
{
	return ( (ch2 >= 'a' && ch2 <= 'z') || (ch2 >= 'A' && ch2 <= 'Z') );
}
bool DfhIsDecimal2( char ch2 )
{
	return ( ch2 >= '0' && ch2 <= '9');
}


int64_t DfhConvU64ToS64Safe2( uint64_t inp )
{
	static_assert( sizeof(int64_t) == 8, "");
	static_assert( sizeof(uint64_t) == 8, "");
	
	const uint64_t uSignedMax2 = 0x7FFFFFFFFFFFFFFF;
	const int64_t  nSignedMax3 = 0x7FFFFFFFFFFFFFFF;
	static_assert( uSignedMax2 == uint64_t(nSignedMax3), "");
	if( inp <= uSignedMax2 ){
		return static_cast<int64_t>(inp);
	}else{
		int64_t nn2 = static_cast<int64_t>( inp + uSignedMax2 ) - nSignedMax3;
		return nn2;
	}
}
std::string DfhConvU64ToStr2( uint64_t inp, size_t uBase2,
				int32_t nPaddTo2,
				const char* flags2 )
{
	assert( uBase2 >= 2 && uBase2 <= 62 );
	assert( nPaddTo2 >= -256 && nPaddTo2 <= 256 );
	assert( !!flags2 );
	const bool bAppendNBaseChar2   = !!std::strchr( flags2, 'c');
	const bool bToLwrHex3          = !!std::strchr( flags2, 'x');
	const bool bPaddWithZero2      = !!std::strchr( flags2, '0');
	const bool bPreppendMinus2     = !!std::strchr( flags2, 'm');
	const bool bPreppendPlus2      = !!std::strchr( flags2, 'P');
	std::string outp;
	{
		if( !inp ){
			outp = "0";
		}else{
			for( ; inp; ){
				const uint64_t uRmndr2 = inp % uBase2;
				assert( uRmndr2 < 62 );
				if( uRmndr2 < 10 ){
					outp += char('0' + uRmndr2);
				}else if( uRmndr2 < 36 ){
					outp += char('A' + (uRmndr2-10));
				}else if( uRmndr2 < 62 ){
					outp += char('a' + (uRmndr2-36));
				}else{
					assert(!"Unreachable [3ygRbi]");
				}
				inp /= uBase2;
			}
			std::reverse( outp.begin(), outp.end() );
		}
	}
	if( bToLwrHex3 && uBase2 < 36 ){
		std::transform( outp.begin(), outp.end(), outp.begin(),
			[]( char ch2 )->char{
				return (( ch2 >= 'A' && ch2 <= 'Z' ) ? ('a' + (ch2 - 'A')) : ch2 );
		});
	}
	if( bAppendNBaseChar2 && !nPaddTo2 ){
		outp += ( (uBase2 == 2) ? "(b)" : ( (uBase2 == 10) ? "(d)" : ( (uBase2 == 16) ? "(h)": "")));
	}
	if( bPreppendMinus2 || bPreppendPlus2 ){
		outp.insert( outp.begin(), '-' );
	}
	if( nPaddTo2 && outp.size() < size_t( std::abs(nPaddTo2) ) ){
		const char cPadd2 = ( bPaddWithZero2 ? '0' : '\x20' );
		if( nPaddTo2 < 0 ){
			nPaddTo2 = std::abs( nPaddTo2 );
			assert( nPaddTo2 > 0 );
			outp.resize( nPaddTo2, cPadd2 );
		}else{
			if( outp[0] != '-' || cPadd2 != '0' ){
				std::reverse( outp.begin(), outp.end() );
				outp.resize( nPaddTo2, cPadd2 );
				std::reverse( outp.begin(), outp.end() );
			}else{
				outp.erase( outp.begin() );
				nPaddTo2 -= 1;
				std::reverse( outp.begin(), outp.end() );
				outp.resize( nPaddTo2, cPadd2 );
				outp += "-";
				std::reverse( outp.begin(), outp.end() );
			}
		}
	}
	if( bPreppendPlus2 ){
		std::replace( outp.begin(), outp.end(), '-', '+');
	}
	return outp;
}


std::string DfhConvS64ToStr2( int64_t inp, size_t uBase2,
				int32_t nPadding2,
				const char* flags2 )
{
	assert( !!flags2 );
	assert( !std::strchr( flags2, 'P') );
	std::string flags3 = flags2;
	std::string outp;
	if( inp < 0 ){
		uint64_t uVal2;
		uVal2 = ( (inp + 128) * -1 );
		uVal2 += 128;
		flags3 += "m";  // ask prepend minus.
		outp = DfhConvU64ToStr2( uVal2, uBase2, nPadding2, flags3.c_str() );
	}else{
		if( !!std::strchr( flags2, 's') ){
			flags3 += "P";   // ask prepend plus.
		}
		outp = DfhConvU64ToStr2( inp, uBase2, nPadding2, flags3.c_str() );
	}
	return outp;
}


std::string DfhConvFloatToStr2( double inp, int32_t nAllPaddTo2,
				uint32_t uFractionalSize2, const char* flags2_u_ )
{
	assert( !!flags2_u_ );
	assert( nAllPaddTo2 <= 128 && nAllPaddTo2 >= -128 );
	assert( uFractionalSize2 <= 128 );
	char bfr2[192], bufFmt2[64];
	std::snprintf( bufFmt2, sizeof(bufFmt2), "%%%d.%u""f", nAllPaddTo2, uFractionalSize2 );
	std::snprintf( bfr2, sizeof(bfr2), bufFmt2, inp );
	return bfr2;
}


std::string
DfhSf2( const char* fmt2, const std::initializer_list<DfhPfArgVariant6>& args2 )
{
	std::string outp;
	const char* sz2 = fmt2, *end2 = (sz2 + std::strlen(fmt2));

	for( auto iA2 = args2.begin(); iA2 != args2.end(); ++iA2 ){
		const char* sz3 = nullptr;
		for( ;; ){
			if( !(sz3 = std::strchr( sz2, '%')) ){
				goto break_break_ec6GvE;
			}
			if( sz3[1] == '%' ){  
				sz3 += 1;  
				outp.append( sz2, sz3-sz2 );
				sz2 = sz3 + 1;  
				continue;
			}
			break;
		}
		assert( !!sz3 && sz3 < end2 ); (void)end2;
		assert( sz2 <= sz3 );
		assert( *sz3 == '%' );

		outp.append( sz2, sz3-sz2 );
		sz2 = sz3;

		const char* szAtPercent2 = sz3;
		sz3 += 1;
		for( size_t iL2 = 0; iL2 < 32 && !DfhIsAlpha2(*sz3); iL2++, sz3++ ){
		}
		if( !std::strchr("dxXscuf", *sz3 ) ){//dxXscu
			break;
		}
		const char* szAtLetter2 = sz3;
		sz2 = sz3 + 1;

		long nPaddTo3 = 0; uint32_t uPaddFracTo2 = 6;
		{
			assert( !!szAtPercent2 );
			char* szAfterNum2 = nullptr, *dmy2;
			nPaddTo3 = std::strtol( &szAtPercent2[1], &szAfterNum2, 10 );
			nPaddTo3 = std::max<long>( -128, std::min<long>( 128, nPaddTo3 ) );
			if( szAfterNum2 && szAfterNum2[0] == '.' && DfhIsDecimal2( szAfterNum2[1] ) ){
				uPaddFracTo2 = std::strtoul( &szAfterNum2[1], &dmy2, 10 );
				uPaddFracTo2 = std::min<uint32_t>( 128, uPaddFracTo2 );
			}
		}
		std::string arg3;
		if( *szAtLetter2 == 'd' ){
			if( iA2->mEValType2 == DfhPfArgVariant6::EVT_Int2 ){
				int64_t nValS64s = DfhConvU64ToS64Safe2( iA2->mVal2 );
				arg3 = DfhConvS64ToStr2( nValS64s, 10, nPaddTo3, "" );
			}else{
				
				arg3 = (std::string("?_") + std::to_string( DfhConvU64ToS64Safe2( reinterpret_cast<size_t>( iA2->mStr2.c_str() ) ) ));
			}
		}else if( *szAtLetter2 == 'u' ){
			if( iA2->mEValType2 == DfhPfArgVariant6::EVT_Int2 ){
				arg3 = DfhConvU64ToStr2( iA2->mVal2, 10, nPaddTo3, "");
			}else{
				arg3 = (std::string("?u_") + std::to_string( reinterpret_cast<size_t>( iA2->mStr2.c_str() ) ));
			}
		}else if( !!std::strchr("xX", *szAtLetter2 ) ){
			if( iA2->mEValType2 == DfhPfArgVariant6::EVT_Int2 ){
				arg3 = DfhConvU64ToStr2( iA2->mVal2, 16, nPaddTo3, (*szAtLetter2 == 'x' ? "x" : "X"));
			}else{
				arg3 = (std::string("?_") + std::to_string( reinterpret_cast<size_t>( iA2->mStr2.c_str() ) ) );
			}
		}else if( *szAtLetter2 == 's' ){
			if( iA2->mEValType2 == DfhPfArgVariant6::EVT_Str2 ){
				arg3 = iA2->mStr2;
			}else{
				arg3 = (std::string("?~_") +
					std::to_string(iA2->mVal2 % 10000000) + "?");
			}
			if( nPaddTo3 && arg3.size() < size_t(std::abs(nPaddTo3)) ){
				if( nPaddTo3 < 0 ){
					arg3.resize( std::abs(nPaddTo3), '\x20' );
				}else{
					std::string padd2;
					padd2.resize( (nPaddTo3 - arg3.size()), '\x20' );
					arg3 = padd2 + arg3;
				}
			}
		}else if( *szAtLetter2 == 'c' ){
			outp += ( ( iA2->mEValType2 == DfhPfArgVariant6::EVT_Int2 && iA2->mVal2 <= 127 ) ? ( char(iA2->mVal2) ) : '?');
		}else if( *szAtLetter2 == 'f' ){
			if( iA2->mEValType2 == DfhPfArgVariant6::EVT_Float2 ){
				outp += DfhConvFloatToStr2( iA2->mF64Val2, nPaddTo3, uPaddFracTo2, "");
			}else{
				outp += (std::string("?._") + std::to_string(iA2->mVal2 % 10000000) + "?");
			}
		}else{
			assert(!"Bad branching [Z2HyNC]");
		}
		outp += arg3;
	}
	break_break_ec6GvE:
	for( const char* sz4; !!(sz4 = std::strstr( sz2, "%%")); sz2 = sz4 + 2 ){  // continue replacein doublee-percent with single-percent.
		outp.append( sz2, ((sz4+1)-sz2) );
	}
	outp.append( sz2 );
	return outp;
}


void DfhPf2( int32_t nLogLevel2, const char* fmt2,
				const std::initializer_list<DfhPfArgVariant6>& args2 )
{
	assert( !!nLogLevel2 );
	if( nLogLevel2 <= DfhPokeLogLevel2(-1,-1,nullptr) ){
		const std::string sr2 = DfhSf2( fmt2, args2 );
		
		
		std::fputs( sr2.c_str(), stderr );
	}
}

int32_t DfhPokeLogLevel2( int32_t nNewLogLevel2, int32_t nNewConditionMethod2, void* reserved2 )
{
	assert( nNewLogLevel2 >= -1 );
	assert( nNewConditionMethod2 == -1 );
	assert( !reserved2 );
	static int32_t nCurrentLogLevel3 = 15;   
	if( nNewLogLevel2 != -1 ){
		nCurrentLogLevel3 = nNewLogLevel2;
	}
	return nCurrentLogLevel3;
}
void DfhUnitTests3()
{
	{
		assert( DfhConvS64ToStr2( -1, 10, 0, "") == "-1" );
		assert( DfhConvS64ToStr2( 0x7FFFFFFFFFFFFFFF,16,0,"") == "7FFFFFFFFFFFFFFF" );
		assert( DfhConvS64ToStr2( 0x7FFFFFFFFFFFFFFF,10,0,"") == "9223372036854775807" );
		assert( DfhConvS64ToStr2( -9223372036854775807, 10, 0, "") == "-9223372036854775807" );
		assert( DfhConvS64ToStr2( -33, 10, 5, "") == "  -33");
		assert( DfhConvS64ToStr2( -33, 10,-5, "") == "-33  ");
		assert( DfhConvS64ToStr2( -3333, 10,-5, "") == "-3333");
		assert( DfhConvS64ToStr2( -3333, 10,-1, "") == "-3333");
		assert( DfhConvS64ToStr2( -33, 10, 5, "0") == "-0033");
		assert( DfhConvS64ToStr2( -33, 10,-5, "0") == "-3300");
		assert( DfhConvS64ToStr2(  33, 10,-5, "s") == "+33  ");

		assert( DfhConvS64ToStr2( 0xABCD, 16, 0, "X") == "ABCD");
		assert( DfhConvS64ToStr2( 0xABCD, 16, 0, "x") == "abcd");
		assert( DfhConvS64ToStr2( 0xABCD, 16, 0, "xc") == "abcd(h)");
		assert( DfhConvU64ToStr2( 9000, 10, 0, "cP") == "+9000(d)");
		assert( DfhConvS64ToStr2( 9000, 10, 0, "cs") == "+9000(d)");
		assert( DfhConvS64ToStr2(-9000, 10, 0, "cs") == "-9000(d)");
	}{
		assert( DfhConvU64ToStr2( 0xFFFFFFFFFFFFFFFF,16,0,"X") == "FFFFFFFFFFFFFFFF");
		
		assert( DfhConvU64ToStr2( 0xFFFFFFFFFFFFFFFF,62,0,"X") == "LygHa16AHYF");
		
		assert( DfhConvU64ToStr2( 123456789,36,0,"") == "21I3V9");
	}{
		assert( DfhSf2("%X", { 0,} ) == "0" );
		assert( DfhSf2("0x%X", { 0xFFFFFFFF,} ) == "0xFFFFFFFF" );
		assert( DfhSf2("%d", { -1,} ) == "-1" );
		assert( DfhSf2("%d", { 0,} ) == "0" );
		assert( DfhSf2("%.d", { 0,} ) == "0" );
		assert( DfhSf2("%%%d%%-%", { 10u,} ) == "%10%-%" );
		assert( DfhSf2("%s,%d", { "abc",-128,} ) == "abc,-128" );
		assert( DfhSf2("%d,bad_percent:%.z...", { -129,} ) == "-129,bad_percent:%.z...");
		assert( DfhSf2("[%5d]",  { 55,} ) == "[   55]" );
		assert( DfhSf2("[%-5d]", { 55,} ) == "[55   ]" );
		assert( DfhSf2("%c%c%c%c%c%c", {'{','!','A','z','/','}',} ) == "{!Az/}");
		assert( DfhSf2("{%c}", {'\x00',} ) == std::string("{\x00}",3) );
		assert( DfhSf2("%u""u", { 18446744073709551615u,} ) == "18446744073709551615u" );
		assert( DfhSf2("[%5s]",  { "abc",} ) == "[  abc]" );
		assert( DfhSf2("[%-5s]", { "abc",} ) == "[abc  ]" );
	}{
		assert( DfhSf2("[%.3f]", { 0.111,} ) == "[0.111]" );
		assert( DfhSf2("[%6.3f]", { 0.111,} ) == "[ 0.111]" );
	}
}
std::string DfhStrReplace3(
	const char* szSubject2, size_t len2,
	const char* szNeedle3, size_t uNdlLen3,
	const char* szReplacement4, size_t uRepLen4,
	size_t uMaxReplacements2, const char* flags2
	)
{
	assert( !!szSubject2 && !!szNeedle3 && !!szReplacement4 && !!flags2 );
	len2     = ( len2     != size_t(-1) ? len2     : std::strlen(szSubject2) );
	uNdlLen3 = ( uNdlLen3 != size_t(-1) ? uNdlLen3 : std::strlen(szNeedle3) );
	uRepLen4 = ( uRepLen4 != size_t(-1) ? uRepLen4 : std::strlen(szReplacement4) );
	uMaxReplacements2 = ( !!uMaxReplacements2 ? uMaxReplacements2 : size_t(-1) );
	if( !uNdlLen3 ){
		return std::string( szSubject2, len2 );
	}
	std::string outp;
	const char* sz2 = szSubject2;
	for( ; uMaxReplacements2; uMaxReplacements2-- ){
		const char* end2 = sz2 + len2;
		const char* sz3 = std::search( sz2, end2, szNeedle3, szNeedle3+uNdlLen3,
			[&]( char ch2, char ch3 ){
				return ch2 == ch3;
		});
		if( sz3 == end2 ){
			break;
		}
		assert( sz3 >= sz2 );
		outp.append( sz2, sz3 - sz2 );
		outp.append( szReplacement4, uRepLen4 );

		assert( len2 >= ( size_t(sz3) - size_t(sz2) ) );
		len2 -= ( sz3 - sz2 );
		sz2 = sz3 + uNdlLen3;
	}
	outp.append( sz2, len2 );
	return outp;
}



std::array<std::string,2> DfhSplitPath2( std::string inp2 )
{
	if( !inp2.empty() ){ 
		for( size_t ii2 = inp2.size(); ii2 && std::strchr("\\/", inp2[ii2-1] ); ii2-- ){
			inp2[ii2-1] = '\x00';
		}
	}
	const char* inp = inp2.c_str();
	const char* sz2 = std::strrchr( inp, '/' );
	const char* sz3 = std::strrchr( inp, '\\' );
	if( (sz2 = std::max<const char*>( sz2, sz3 )) ){
		std::string dirname2( inp, sz2-inp );
		return { dirname2, &sz2[1] };
	}
	return {"", inp,};
}

std::array<std::string,2> DfhSplitExt2( std::string filename2, const char* flags2 )
{
	flags2 = (flags2 ? flags2 : "");
	const bool bGetBaseNameFirst2 = !!std::strchr( flags2, 'b');
	if( bGetBaseNameFirst2 ){
		filename2 = DfhSplitPath2( filename2 )[1];
	}
	const char* inp = filename2.c_str();
	const char* sz2 = std::strrchr( inp, '\\');
	const char* sz3 = std::strrchr( inp, '/');
	const char* sz4 = std::strrchr( inp, '.');
	sz2 = ( sz2 && sz3 ? std::max<const char*>(sz2,sz3) : ( sz2 ? sz2 : sz3 ) );
	if( sz4 && sz4 > sz2 && sz4[1] != 0 ){
		std::string filename3( inp, sz4-inp );
		std::string fileext2( sz4 );
		return { filename3, fileext2,};
	}
	return {inp,"",};
}

std::string DfhConvSecondsToHMSString2( double fSecs4, const char* flags3 )
{
	const bool bInclFrac2      = std::strchr( flags3, 'z');
	const bool bUseHmsLetters2 = std::strchr( flags3, 'a');
	const bool bRounding2      = std::strchr( flags3, 'r');
	fSecs4 = ( fSecs4 < 0.0 ? fSecs4 * -1.0 : fSecs4 );
	assert( fSecs4 >= 0.0 );
	if( bRounding2 ){
		fSecs4 += ( bInclFrac2 ? 0.0005 : 0.5 );
	}
	const uint32_t uSecs2 = static_cast<uint32_t>( fSecs4 );
	uint32_t hhh, mmm, sss, zzz = 0;
	mmm = uSecs2 / 60;
	sss = uSecs2 % 60;
	hhh = mmm / 60;
	mmm = mmm % 60;
	if( bInclFrac2 ){
		double dmy2, fFrac2 = std::modf( fSecs4, &dmy2 );
		assert( fFrac2 < 1.0 );
		zzz = uint32_t( fFrac2 * 1000.0 );
		assert( zzz < 1000 );
	}
	char bfrHms2[128];
	if( !bUseHmsLetters2 ){
		if( bInclFrac2 ){
			std::snprintf( bfrHms2, sizeof(bfrHms2), "%d:%02d:%02d.%03d", hhh,mmm,sss,zzz );
			return bfrHms2;
		}else{
			std::snprintf( bfrHms2, sizeof(bfrHms2), "%d:%02d:%02d", hhh,mmm,sss );
			return bfrHms2;
		}
	}else{
		
		
		char bfrMilli2[32] = "";
		if( bInclFrac2 ){
			std::snprintf( bfrMilli2, sizeof(bfrMilli2), "%03d""ms", zzz );
		}
		std::snprintf( bfrHms2, sizeof(bfrHms2), "%d""h""%02d""m""%02d""s""%s",
				hhh,mmm,sss, bfrMilli2 );
		return bfrHms2;
	}
}
