#pragma once
#include <string>
#include <vector>
#include <array>
#include <functional>
#include "dfh_core.hh"
#ifdef _MSC_VER
	#pragma warning( disable : 4100 )  
	#pragma warning( disable : 4996 )  
	#pragma warning( disable : 4706 )  
#endif

struct AsuWaveFmtDesc2; struct AsuRWCapacityBuffer6; 

std::string AsuSf2( const char* fmt, ... );
bool        AsuAnyCStr2( const char* needle2, const std::initializer_list<const char*>& haysack2, const char* flags2_u_ );
bool        AsuAnyU32u2( uint32_t needle2, const std::initializer_list<uint32_t>& haysack2 );
auto        AsuGetMultiChanSampleAsBytes2( const void* data2, size_t uDataLen2, size_t uBitsPerSample2, size_t uNumChannels2 ) -> std::basic_string<uint8_t>;
std::string AsuGetMultiChanSampleAsStrBytes2( const void* data2, size_t uDataLen2, size_t uBitsPerSample2, size_t uNumChannels2, const char* flags2 );
std::string AsuConvStdErrorCodeToStr2( int nStdErrorCode, const char* flags3 );
std::string AsuHexDump2( const void* data2, size_t uDataLen2, const char* flags4 );

int16_t     AsuConvU08ToS16LLWise2( uint8_t inp );
int16_t     AsuConvS32ToS16LLWise2( int32_t inp );
auto        AsuConvU16ToLEBytes2( uint16_t inp ) -> std::array<uint8_t,2>;
auto        AsuConvU32ToLEBytes2( uint32_t inp ) -> std::array<uint8_t,4>;
uint16_t    AsuUnpackU16LEBytes2( const void* data2 );
int16_t     AsuUnpackS16LEBytes2( const void* data2 );
uint32_t    AsuUnpackU32LEBytes2( const void* data2 );
int         AsuFseek2( std::FILE*, uint64_t uOffset2 );
std::string AsuStrReplProvideSafeChars2( const void* sz2, size_t num2 );
std::string AsuStrReplProvideSafeChars3( const std::string& inp );
bool        AsuIsPrintableChar2( char ch2 );
auto        AsuProcessStandardStream2( std::FILE* stream3, size_t uElementSize2, uint64_t uMaxReadOrUntillEof3, const AsuRWCapacityBuffer6* cBfr2, const std::function<bool( const uint8_t*, size_t num2, std::string* err )>& ) -> DfhQuad2<bool,std::string,uint64_t>;
auto        AsuWaveCreateFileHeaderPlaceholder2( const AsuWaveFmtDesc2& sFmtDesc2, uint64_t* uFileSizeOffsetOut2, uint64_t* uDataSizeOffsetOut2 ) -> std::vector<uint8_t>;
std::string AsuGetCompilerString2();
bool        AsuIsWithinInterval2( double inp, double fLo, double fHi, const char* flags2 );


struct AsuRWCapacityBuffer6{
	AsuRWCapacityBuffer6();
	AsuRWCapacityBuffer6( const AsuRWCapacityBuffer6& otherr ) = delete;
	void operator=( const AsuRWCapacityBuffer6& otherr ) = delete;
	virtual void   AsuCBiReserve2( size_t uNumBytes2 );
	virtual size_t AsuCBiCapacity2()const;
	virtual bool   AsuCBiResize2( size_t uNumBytes2 )const;
	virtual size_t AsuCBiGetSize2()const {return mData2.size();}
	virtual auto   AsuCBiGetData2()const -> uint8_t* {return mData2.data();}
private:
	mutable std::vector<uint8_t> mData2;
};

enum AsuAudFeedType2 : size_t {
	ASU_E8_AFTypePristine2 = 110445901,
	ASU_E8_AFTypeSpoiled2,
};

struct AsuFeedAudS16Param7{
	const int16_t*  pSamples3    = nullptr;
	size_t          uNumSamples3 = 0;
	AsuAudFeedType2 eAFType2     = ASU_E8_AFTypePristine2;
};
struct AsuWriteOutStreamBase2{
	virtual auto AsuWOiInitializeOutputFile2( const char* szOutpFileName2, const char* flags2 ) -> DfhQuad2<bool,std::string> = 0;
	virtual void AsuWOiSetWaveFormat2( const AsuWaveFmtDesc2& inp ) = 0;
	virtual bool AsuWOiFinalizeOutputFile2() = 0;
};
struct AsuReceiverFilterBase2{
	virtual bool AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp ) = 0;
};
struct AsuAudioFilterBase2 : AsuReceiverFilterBase2{
	virtual void AsuAFiSetFrequency2( size_t num ) = 0;
	virtual void AsuAFiSetAudioReceiver2( AsuReceiverFilterBase2* ) {};
	virtual bool AsuAFiFinalize2() {return 1L;};
	virtual auto AsuAFiGetName2()const -> std::string = 0;
};


struct AsuWaveFmtDesc2 {
	uint32_t    uFrequency2 = 0;   
	uint16_t    uNumChannels2 = 0;
	uint16_t    uAudioFormat2 = 0;
	uint16_t    uBitsPerSample2 = 0;
	std::string srAudioFormatName2;
	struct{
		uint32_t uBytesPerSecond2 = 0;
		uint32_t uBytesPerFrame2 = 0;
	}sCalculated2;
	explicit operator bool()const {return !!this->uFrequency2;}
	bool     isSameFormat2( const AsuWaveFmtDesc2& otherr )const;
};
enum : size_t {
	ASU_E5_WaveAudioFormatPCMInteger2 = 1,  
	ASU_E5_WaveAudioFormatIEEE754Float2 = 3,  
};
struct AsuAudioInterval7{
	double   fStartSecs2  = 0.0;
	double   fEndSecs2    = 0.0;
	uint64_t uStartFrame2 = 0;
	uint64_t uEndFrame2   = 0;
};
struct AsuTextLogger6 {
	virtual void AsuTLiAddAudioInterval2( const AsuAudioInterval7& inp ) = 0;
};

