#include "asu_af_detector.hh"
#include <cassert>  
#include "dfh_reinterpolate.hh"
#include "dfh_cma_average.hh"


double AsuConvSampleS16AbsToFractionF64f2( int16_t nSample2 )
{
	if( nSample2 >= 0 ){
		const int16_t nMax2 = std::numeric_limits<int16_t>::max();
		const double fFrac2 = double(nSample2) / double(nMax2);
		assert( fFrac2 >= 0.0 && fFrac2 <= 1.0 );
		return fFrac2;
	}else{
		assert( nSample2 < 0 );
		static const int32_t nMax3 = std::abs( int32_t( std::numeric_limits<int16_t>::min()));
		const int32_t nSample3 = std::abs( int32_t( nSample2 ) );
		assert( nSample3 > 0 );   
		assert( nSample3 <= nMax3 );
		const double fFrac3 = double(nSample3) / double(nMax3);
		assert( fFrac3 >= 0.0 && fFrac3 <= 1.0 );
		return fFrac3;
	}
}
uint32_t AsuConvSampleS16AbsToFractionU32u2( int16_t nSample2 )
{
	const uint32_t uU32Max2 = uint32_t(-1);
	double frac2 = AsuConvSampleS16AbsToFractionF64f2( nSample2 );
	assert( frac2 >= 0.0 && frac2 <= 1.0 );
	uint32_t uU32Frac2 = uint32_t(frac2 * double( uU32Max2 ));
	return uU32Frac2;
}

double AsuConvSampleS16ToFracSegmentAligned2(
			int16_t nSample2, size_t uNumSegments2,
			bool bHalfUpperBias2 )
{
	const uint32_t uU32Max2 = uint32_t(-1);
	assert( uNumSegments2 <= uU32Max2 );
	assert( !!uNumSegments2 );
	const uint32_t uSegSize2 = (uU32Max2 / uint32_t(uNumSegments2));

	uint32_t uFrac2 = AsuConvSampleS16AbsToFractionU32u2( nSample2 );
	if( bHalfUpperBias2 && uFrac2 > uU32Max2/2 ){
		uFrac2 = uint32_t( std::min<uint64_t>( (uint64_t(uFrac2) + (uSegSize2/2)), uU32Max2 ) );
	}
	uint32_t uFrac3 = ( uint32_t(uFrac2 / uSegSize2) * uSegSize2);
	double frac2 = double(uFrac3) / double(uU32Max2);

	return frac2;
}
void AsuSilenceDetectorFilter2::AsuAFiSetAudioReceiver2( AsuReceiverFilterBase2* pReceiver2 )
{
	assert( pReceiver2 );
	mReceiver2 = pReceiver2;
}

void AsuSilenceDetectorFilter2::setSilenceLogger2( AsuTextLogger6* inp )
{
	assert( !mSilenceLogger2.second );
	assert( !mSilenceLogger2.first );
	mSilenceLogger2.second = inp;
}
double AsuSilenceDetectorFilter2::calculateProbeVolume2( const std::vector<int16_t>& aProbeValues2 )const
{
	assert( !aProbeValues2.empty() );
	DfhCMAAverage2<double> cAvg3;

	using UnitAmplifyFunc_t = double(*)(double);

	UnitAmplifyFunc_t fncUnitAmplify2;
	if(0){
	}else if( mSilConf2.eUnitAmpMethod2 == ASU_E7_UnitAmplify_CircleNWQuadrant2 ){
		fncUnitAmplify2 = DfhUnitAmplifyCircleNWQuadrant2;
	}else if( mSilConf2.eUnitAmpMethod2 == ASU_E7_UnitAmplify_QuarterSine ){
		fncUnitAmplify2 = DfhUnitAmplifyQuarterSine2;
	}else if( mSilConf2.eUnitAmpMethod2 == ASU_E7_UnitAmplify_None ){
		fncUnitAmplify2 = []( double x )->double{return x;};

	}else if( mSilConf2.eUnitAmpMethod2 == ASU_E7_UnitAmplify_SCurveNWSEArcs2 ){
		fncUnitAmplify2 = DfhUnitAmplifySCurveNWSEQuadrants2;
	}else{
		fncUnitAmplify2 = nullptr;
		assert(!"LVDAU: Bad branching [dy0s0Q]");
	}
	std::for_each( aProbeValues2.begin(), aProbeValues2.end(),
		[&]( const int16_t nSample2 ){
			double frac2 = AsuConvSampleS16AbsToFractionF64f2( nSample2 );
			frac2 = fncUnitAmplify2( frac2 );
			cAvg3.update2( frac2 );
	});
	double avg2 = cAvg3.getAvg();
	assert( avg2 >= 0.0 && avg2 <= 1.0 );
	return avg2;
}

AsuSilenceDetectorFilter2::
AsuSilenceDetectorFilter2( const AsuSilenceDefinition2& cSilDef2 )
	: mSilConf2( cSilDef2 )
{
	assert( !!mSilConf2.fProbeDurationSecs2 );
}
void AsuSilenceDetectorFilter2::AsuAFiSetFrequency2( size_t uNumFramesPerSec2 )
{
	assert( !!uNumFramesPerSec2 );
	mNumFramesPerSec2 = uNumFramesPerSec2;
	mNumFramesPerProbe2 = std::max<size_t>( 1, size_t( mNumFramesPerSec2 * mSilConf2.fProbeDurationSecs2 ) );
	if( mNumFramesPerProbe2 < ASU_E6_MinSamplesPerProbeSanity2 ){
		DfhPf2(4,"LVDAU: WARN: Number of audio frames per probe seems a very low value (%s) [26n1d2]\n", { std::to_string(mNumFramesPerProbe2).c_str(),});
	}
	DfhPf2(6,
		"LVDAU: %s - Configuration:\n", { this->AsuAFiGetName2().c_str(),});
	DfhPf2(6,
		"       Probe Duration: %s (sec), #Frames/Probe: %s,\n"
		"       Frequency: %s (#frames/sec), Silence Threshold: %s,\n"
		"       Minimum Silence Duration: %s(sec)\n"
		,{
			DfhConvFloatToStr2( mSilConf2.fProbeDurationSecs2, 0, 18, "").c_str(),
			std::to_string(mNumFramesPerProbe2).c_str(),
			std::to_string(mNumFramesPerSec2).c_str(),
			DfhConvFloatToStr2( mSilConf2.fSilenceThresholdFrac2, 0, 18, "").c_str(),
			DfhConvFloatToStr2( mSilConf2.fMinSilenceDurationSecs2, 0, 18, "").c_str(),
			});
	if( !AsuIsWithinInterval2( mSilConf2.fSilenceThresholdFrac2, 0.0, 1.0, "oo") ){
		DfhPf2(4,"LVDAU: WARN: Silence threshold is out of range (0.0 < %s < 1.0) \n", {
			DfhConvFloatToStr2( mSilConf2.fSilenceThresholdFrac2, 0, 18, "").c_str(),});
	}
}
double AsuSilenceDetectorFilter2::calculateCurrentProbeVolume2()const
{
	assert( !mProbeBuffer2.empty() );
	double avg2 = this->calculateProbeVolume2( mProbeBuffer2 );
	assert( avg2 >= 0.0 );
	assert( avg2 <= 1.0 );
	return avg2;
}
double AsuSilenceDetectorFilter2::convFrameSizeToSeconds2( uint64_t uFramePos2 )const
{
	assert( !!mNumFramesPerSec2 );
	double fSecs2 = ( double( uFramePos2 ) / mNumFramesPerSec2 );
	return fSecs2;
}
std::string AsuSilenceDetectorFilter2::
getStartEndInSecondsAsString2( double fBegin2, double fEnd2 )const
{
	std::string outp = DfhSf2("%s - %s (%s - %s seconds)", {
		DfhConvSecondsToHMSString2( fBegin2, "zr"),
		DfhConvSecondsToHMSString2( fEnd2, "zr"),
		std::to_string( fBegin2 ),
		std::to_string( fEnd2 ),
	});
	return outp;
}
void AsuSilenceDetectorFilter2::
sendAndClearSilence2( std::vector<int16_t>* aSilBfr2, uint64_t uStartAtFrame2, uint64_t uEndAtFrame2 )
{
	assert( !!aSilBfr2 );
	const double fStartAtSecs3 = this->convFrameSizeToSeconds2( uStartAtFrame2 );
	const double fEndAtSecs4   = this->convFrameSizeToSeconds2( uEndAtFrame2 );
	DfhPf2(6,"LVDAU: Detection: silence start-end: %s\n", {
		this->getStartEndInSecondsAsString2( fStartAtSecs3, fEndAtSecs4 )
	});
	if( !mSilConf2.bKeepShowAllSilences2 && mDetectedSilences2.size() >= 2 ){
		mDetectedSilences2.resize( 1 );
	}
	AsuAudioInterval7 dsr2;
	dsr2.fStartSecs2  = fStartAtSecs3;
	dsr2.fEndSecs2    = fEndAtSecs4;
	dsr2.uStartFrame2 = uStartAtFrame2;
	dsr2.uEndFrame2   = uEndAtFrame2;
	mDetectedSilences2.push_back( dsr2 );
	this->addSilenceLogIfNeeded2( dsr2 );
	this->sendAndClearBuffer2( aSilBfr2, ASU_E8_AFTypeSpoiled2 );
	;
	assert( aSilBfr2->empty() );
}
bool AsuSilenceDetectorFilter2::AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp )
{
	assert( !!mNumFramesPerSec2 && !!mNumFramesPerProbe2 );
	assert( !!inp.pSamples3 );
	assert( !!inp.uNumSamples3 );
	assert( inp.eAFType2 == ASU_E8_AFTypePristine2 );
	assert( !!mReceiver2 );
	for( size_t ii2 = 0; ii2 < inp.uNumSamples3; ii2++, mCurrFrame2++ ){
		assert( mProbeBuffer2.size() < mNumFramesPerProbe2 );
		mProbeBuffer2.push_back( inp.pSamples3[ii2] );
		if( mProbeBuffer2.size() == mNumFramesPerProbe2 ){
			const double volume2 = this->calculateCurrentProbeVolume2();
			
			
			
			if( volume2 < mSilConf2.fSilenceThresholdFrac2 ){
				if( !mIsInSilenceState2 ){
					mCurrSilenceStartFrame2 = mCurrFrame2;
					assert( mCurrSilenceStartFrame2+1 >= mProbeBuffer2.size() );
					assert( !mProbeBuffer2.empty() );
					mCurrSilenceStartFrame2 -= (mProbeBuffer2.size() - 1);
					mIsInSilenceState2 = 1L;
					mSilenceBuffer2.clear();
				}
				assert( mIsInSilenceState2 );
				std::copy( mProbeBuffer2.begin(), mProbeBuffer2.end(), std::back_inserter(mSilenceBuffer2) );
				mStatMaxSilenceBufSize2 = std::max( mStatMaxSilenceBufSize2, mSilenceBuffer2.size() );
			}else{
				if( mIsInSilenceState2 ){
					assert( mCurrSilenceStartFrame2 != uint64_t(-1) );
					assert( mCurrSilenceStartFrame2 < mCurrFrame2 );
					const double fStartAtSecs2 = this->convFrameSizeToSeconds2( mCurrSilenceStartFrame2 );
					const double fEndAtSecs3   = this->convFrameSizeToSeconds2( mCurrFrame2 );
					assert( fStartAtSecs2 < fEndAtSecs3 );
					const double fSilLen2 = fEndAtSecs3 - fStartAtSecs2;
					const bool bIsSilence2 = fSilLen2 >= mSilConf2.fMinSilenceDurationSecs2;
					const bool bOmit2 = ( !mNumSilencesDetected2 ? mSilConf2.bOmitLeadingSience2 : mSilConf2.bOmitMiddleSiences2 );
					mNumSilencesDetected2 += !!bIsSilence2;
					if( bIsSilence2 && !bOmit2 ){
						
						
						
						
						
						this->sendAndClearSilence2(
							&mSilenceBuffer2, mCurrSilenceStartFrame2, mCurrFrame2 );
						assert( mSilenceBuffer2.empty() );
					}else{
						
						assert( !mSilenceBuffer2.empty() );
						this->sendAndClearBuffer2( &mSilenceBuffer2, ASU_E8_AFTypePristine2 );
					}
					mIsInSilenceState2 = 0L;
					mCurrSilenceStartFrame2 = uint64_t(-1);
				}
				assert( !mIsInSilenceState2 );
				this->sendAndClearBuffer2( &mProbeBuffer2, ASU_E8_AFTypePristine2 );
			}
			mProbeBuffer2.clear();
		}
	}
	return 1L;
}
void AsuSilenceDetectorFilter2::sendAndClearBuffer2( std::vector<int16_t>* aBuffer2, AsuAudFeedType2 eAFTy2 )const
{
	assert( !!mReceiver2 );
	assert( !!aBuffer2 );
	assert( !aBuffer2->empty() );
	AsuFeedAudS16Param7 fad2;
	fad2.pSamples3    = aBuffer2->data();
	fad2.uNumSamples3 = aBuffer2->size();
	fad2.eAFType2     = eAFTy2;
	bool rs2 = mReceiver2->AsuRFiFeedAudioData2( fad2 );
	assert( !!rs2 );
	aBuffer2->clear();
}
bool AsuSilenceDetectorFilter2::AsuAFiFinalize2()
{
	assert( !!mReceiver2 );
	DfhPf2(8,
		"LVDAU: %s - Finalizing. End Position: %s (%s seconds).\n"
		"       Longest silence duration detected: %s seconds\n"
		"       Volume of the final probe: %s\n"
		"       Final silence size: %s frames\n"
		"       Final probe is not processed (size: %s frames)\n", {
		this->AsuAFiGetName2().c_str(),
		std::to_string( mCurrFrame2).c_str(),
		std::to_string( this->convFrameSizeToSeconds2(mCurrFrame2)).c_str(),
		std::to_string( this->convFrameSizeToSeconds2(mStatMaxSilenceBufSize2)).c_str(),
		std::to_string( this->calculateCurrentProbeVolume2()).c_str(),
		std::to_string( mSilenceBuffer2.size()).c_str(),
		std::to_string( mProbeBuffer2.size()).c_str(),});
	if( !mSilenceBuffer2.empty() ){
		const double fSilLen3 = this->convFrameSizeToSeconds2( mSilenceBuffer2.size() );
		if( fSilLen3 >= mSilConf2.fMinSilenceDurationSecs2 && !mSilConf2.bOmitTrailingSience2 ){
			mNumSilencesDetected2 += 1;
			this->sendAndClearSilence2( &mSilenceBuffer2,
					(mCurrFrame2 - mSilenceBuffer2.size()), mCurrFrame2 );
		}else{
			this->sendAndClearBuffer2( &mSilenceBuffer2, ASU_E8_AFTypePristine2 );
		}
	}
	if( !mProbeBuffer2.empty() ){
		this->sendAndClearBuffer2( &mProbeBuffer2, ASU_E8_AFTypePristine2 );
	}
	{
		DfhPf2(6,"LVDAU: Detected silence parts (%s)%s\n",{
			std::to_string( mNumSilencesDetected2 ).c_str(),  
			( mNumSilencesDetected2 ? ":":""), });
		if( !mDetectedSilences2.empty() ){
			DfhPf2(6,"       * First Silence : %s\n", {
					this->getStartEndInSecondsAsString2(
						mDetectedSilences2.begin()->fStartSecs2,
						mDetectedSilences2.begin()->fEndSecs2 ),
				});
		}
		if( mDetectedSilences2.size() >= 2 ){
			DfhPf2(6,"       * Last Silence  : %s\n", {
					this->getStartEndInSecondsAsString2(
						mDetectedSilences2.back().fStartSecs2,
						mDetectedSilences2.back().fEndSecs2 ),
				});
		}
	}
	return 1L;
}

void AsuSilenceDetectorFilter2::addSilenceLogIfNeeded2( const AsuAudioInterval7& intrvl2 )
{
	if( !mSilenceLogger2.second ){
		return;
	}
	mSilenceLogger2.second->AsuTLiAddAudioInterval2( intrvl2 );
}