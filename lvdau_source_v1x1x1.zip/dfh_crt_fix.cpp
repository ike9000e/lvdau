#include "dfh_crt_fix.hh"
#ifdef __MINGW32__
	#undef __STRICT_ANSI__   
	#include <fcntl.h>
	
#endif
#if defined(_WIN32) && defined(_MSC_VER)
	#include <io.h>      
	#include <fcntl.h>   
#endif
#include <stdio.h>
#include <cstdio>
#include <cassert>  

#ifdef _MSC_VER
	#pragma warning( disable : 4100 )  
	#pragma warning( disable : 4996 )  
#endif


void DfhSetStdStreamBinaryMode2( void* std_stream2 )
{
	assert( !!std_stream2 );
	std::FILE* std_stream3 = reinterpret_cast<std::FILE*>( std_stream2 );
	#ifdef __MINGW32__   
		_setmode( _fileno(std_stream3), _O_BINARY );
	#endif
	#if defined(_WIN32) && defined(_MSC_VER)
		_setmode( _fileno(std_stream3), _O_BINARY );
	#endif
}