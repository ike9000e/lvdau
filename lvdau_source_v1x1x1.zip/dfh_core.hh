#pragma once
#include <string>
#include <vector>
#include <array>
#include <cstdint>   


struct DfhPfArgVariant6;

std::string DfhSf2( const char* fmt2, const std::initializer_list<DfhPfArgVariant6>& args2 );
void        DfhPf2( int32_t nLogLevel2, const char* fmt2, const std::initializer_list<DfhPfArgVariant6>& args2 );
bool        DfhIsAlpha2( char );
bool        DfhIsDecimal2( char ch2 );
std::string DfhStrReplace3( const char* subject2, size_t len2, const char* needle3, size_t uNdlLen3, const char* replacement4, size_t uRepLen4, size_t uMaxReplacements2, const char* flags2 );
std::string DfhHexEncode2( const void* data_, size_t size2, const char* flags2 );
std::string DfhHexEncode3( const std::vector<uint8_t>& data_, const char* flags2 );
void        DfhHexEncode4( const void* data_, size_t size2, const char* flags2, std::string* outp );
auto        DfhHexDecode2( const char* data_, size_t size2, const char* flags2, std::string* err_ ) -> std::vector<uint8_t>;
auto        DfhHexDecode3( const std::string& data_ ) -> std::vector<uint8_t>;
size_t      DfhStrlenMaxAdvance2( const char* inp, size_t uMaxAdvance2 );
const char* DfhStrpbrkMaxAdvance2( const char* inp, const char* charset2, size_t uMaxAdvance2 );
int64_t     DfhConvU64ToS64Safe2( uint64_t inp );
std::string DfhConvU64ToStr2( uint64_t inp, size_t uBase2, int32_t nPadding2, const char* flags2 );
std::string DfhConvS64ToStr2( int64_t inp, size_t uBase2, int32_t nPadding2, const char* flags2 );
void        DfhUnitTests3();
int32_t     DfhPokeLogLevel2( int32_t nLogLevel2, int32_t nNewConditionMethod2, void* reserved2 );
auto        DfhSplitPath2( std::string inp2 ) -> std::array<std::string,2>;
auto        DfhSplitExt2( std::string filename2, const char* flags2 ) -> std::array<std::string,2>;
std::string DfhConvSecondsToHMSString2( double inp, const char* flags3 );
std::string DfhConvFloatToStr2( double inp, int32_t, uint32_t nFractionalSize2, const char* flags2 );


template<class Txx, class Uxx, class Vxx = char, class Xxx = char>
struct DfhQuad2{
	Txx first;
	Uxx second;
	Vxx third;
	Xxx fourth;
	;          DfhQuad2( const Txx& a, const Uxx& b, const Vxx& c = {}, const Xxx& d = {} ) : first(a), second(b), third(c), fourth(d) {}
	;          DfhQuad2() = default;
	const Txx& operator*()const {return first;}
	Txx&       operator*()      {return first;}
	const Uxx& operator+()const {return second;}
	Uxx&       operator+()      {return second;}
};


struct DfhPfArgVariant6 {
	DfhPfArgVariant6( const std::string& inp ) {mStr2 = inp; mEValType2 = EVT_Str2;}
	DfhPfArgVariant6( const char* inp ) {mStr2 = inp; mEValType2 = EVT_Str2;}
	DfhPfArgVariant6( uint64_t inp ) {mVal2 = inp;}
	DfhPfArgVariant6( uint32_t inp ) {mVal2 = inp;}
	DfhPfArgVariant6( uint16_t inp ) {mVal2 = inp;}

	template<class Txx, class = typename std::enable_if<
		std::is_signed<Txx>::value
		&& !std::is_floating_point<Txx>::value
		,int>::type>
	DfhPfArgVariant6( Txx inp ) {mVal2 = inp;}
	DfhPfArgVariant6( double inp ) { mF64Val2 = inp; mEValType2 = EVT_Float2;}
	
	static_assert( sizeof(uint64_t) <= sizeof(unsigned long long), "");
	enum E_ValTy2 : uint8_t { EVT_Str2=1, EVT_Int2, EVT_Float2,};
	std::string mStr2;
	uint64_t mVal2 = 0;
	double mF64Val2 = 0.0;
	E_ValTy2 mEValType2 = EVT_Int2;
};