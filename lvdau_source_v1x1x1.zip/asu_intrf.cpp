#include "asu_intrf.hh"
#include <cassert>  
#include <cstdarg>  
#include <cstring> 
#include <limits>
#include <cmath>
#include <algorithm>







std::string AsuSf2( const char* fmt2, ... )
{
	std::string outp;
	std::va_list arg;
    va_start(arg, fmt2);
	{
		char bfr3[1];
		int num = std::vsnprintf( bfr3, 0, fmt2, arg );
		assert( num >= 0 );
		std::vector<char> bfr4;
		bfr4.resize( num + 1 );
		bfr4[0] = 0;
		
		
		
		va_start( arg, fmt2 );
		std::vsnprintf( &bfr4[0], bfr4.size(), fmt2, arg );
		outp = bfr4.data();
	}
	va_end(arg);
	return outp;
}
bool AsuAnyCStr2( const char* needle2, const std::initializer_list<const char*>& haysack2, const char* flags2_u_ )
{
	const size_t num2 = haysack2.size();
	const auto* bgn = &haysack2.begin()[0];
	for( size_t ii2=0; ii2 < num2; ii2++ ){
		if( !std::strcmp( needle2, bgn[ii2] ) ){
			return 1L;
		}
	}
	return 0L;
}
bool AsuAnyU32u2( uint32_t needle2, const std::initializer_list<uint32_t>& haysack2 )
{
	const size_t num2 = haysack2.size();
	const auto* bgn = &haysack2.begin()[0];
	for( size_t ii2=0; ii2 < num2; ii2++ ){
		if( needle2 == bgn[ii2] ){
			return 1L;
		}
	}
	return 0L;
}

std::basic_string<uint8_t>
AsuGetMultiChanSampleAsBytes2( const void* data2, size_t uDataLen2,
		size_t uBitsPerSample2, size_t uNumChannels2 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	assert( uBitsPerSample2 >= 8 );
	assert( !(uBitsPerSample2 % 8) );
	const size_t uNumBytes2 = ( (uBitsPerSample2 / 8) * uNumChannels2 );
	assert( uNumBytes2 <= uDataLen2 );
	std::basic_string<uint8_t> outp;
	std::copy( &data3[0], &data3[uNumBytes2], std::back_inserter(outp) );
	return outp;
}
std::string AsuGetMultiChanSampleAsStrBytes2( const void* data2, size_t uDataLen2,
				size_t uBitsPerSample2, size_t uNumChannels2, const char* flags2 )
{
	const bool bUseSpace2 = !!std::strchr( flags2, 's');
	const bool bNoSep2    = !!std::strchr( flags2, 'e');
	const char* sep2 = (bNoSep2 ? "" : ( bUseSpace2 ? "\x20" : ","));

	const auto bytes2 = AsuGetMultiChanSampleAsBytes2( data2, uDataLen2, uBitsPerSample2, uNumChannels2 );
	std::string out2; char bfr2[32];
	for( size_t ii2=0; ii2 < bytes2.size(); ii2++ ){
		std::snprintf( bfr2, sizeof(bfr2), "%02X", int(uint32_t( bytes2[ii2] )) );
		out2 += ( std::string( ii2 ? sep2 : "") + bfr2 );
	}
	return out2;
}
std::string AsuHexDump2( const void* data2, size_t uDataLen2, const char* flags4 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	const bool bUseSpace2 = !!std::strchr( flags4, 's');
	const bool bNoSep2    = !!std::strchr( flags4, 'e');
	const char* sep2 = (bNoSep2 ? "" : ( bUseSpace2 ? "\x20" : ","));
	std::string outp; char bfr2[16];
	for( size_t ii2=0; ii2 < uDataLen2; ii2++ ){
		std::snprintf( bfr2, sizeof(bfr2), "%02X", int32_t(uint32_t( data3[ii2] )));
		outp += ( std::string( ii2 ? sep2 : "") + bfr2 );
	}
	return outp;
}

std::string AsuConvStdErrorCodeToStr2( int nStdErrorCode, const char* flags3 )
{
	flags3 = ( flags3 ? flags3 : "" );
	const bool bEmptyIfUnknown2 = !!std::strchr( flags3, 'e' );
	const char* sz2 = std::strerror( nStdErrorCode );
	if( sz2 && *sz2 ){
		return sz2;
	}
	return ( bEmptyIfUnknown2 ? "" : "Unknown standard error [cIXFHr]" );
}


int16_t AsuConvS32ToS16LLWise2( int32_t inp )
{
	if( inp >= 0 ){
		double  frac3 = ( double(inp) / double(std::numeric_limits<int32_t>::max()));
		return int16_t( frac3 * double(std::numeric_limits<int16_t>::max()));
	}else{
		
		
		int64_t val3 = inp;
		assert( val3 < 0 );
		val3 *= -1;
		assert( val3 > 0 );
		double  frac4 = ( double(val3) / double(std::fabs( double(std::numeric_limits<int32_t>::min()))));
		assert( frac4 >= 0.0 );
		int32_t val4  = int32_t( frac4 * double(std::fabs( double(std::numeric_limits<int16_t>::min()))));
		assert( val4 <= std::abs(int32_t(std::numeric_limits<int16_t>::min())));
		return int16_t( val4 * -1 );
	}
}

int16_t AsuConvU08ToS16LLWise2( uint8_t val2 )
{
	float    frac2 = ( float(val2) / float(std::numeric_limits<uint8_t>::max()));
	uint16_t val3  = uint16_t( float(frac2) * float(std::numeric_limits<uint16_t>::max()) );
	int32_t  val4  = int32_t(val3) - std::abs( int32_t(std::numeric_limits<int16_t>::min()) );
	int16_t  val5  = int16_t(val4);
	return val5;
}


std::array<uint8_t,2> AsuConvU16ToLEBytes2( uint16_t val2 )
{
	std::array<uint8_t,2> outp;
	outp[0] = uint8_t( val2      & 0xFF );
	outp[1] = uint8_t( val2 >> 8 & 0xFF );
	return outp;
}
std::array<uint8_t,4> AsuConvU32ToLEBytes2( uint32_t val4 )
{
	std::array<uint8_t,4> outp;
	outp[0] = uint8_t( val4       & 0xFF );
	outp[1] = uint8_t( val4 >> 8  & 0xFF );
	outp[2] = uint8_t( val4 >> 16 & 0xFF );
	outp[3] = uint8_t( val4 >> 24 & 0xFF );
	return outp;
}


int AsuFseek2( std::FILE* fp4, uint64_t uOffset2 )
{
	assert( uOffset2 <= std::numeric_limits<long>::max() );
	const long nOffset2 = (long) uOffset2;
	const int result2 = std::fseek( fp4, nOffset2, SEEK_SET );
	if( result2 ){  
		return result2;
	}
	if( std::ferror( fp4 ) ){  
		return 2807980;
	}
	const long nNewOffset2 = std::ftell( fp4 );
	if( nNewOffset2 == -1 ){  
		return 8657709;
	}
	if( nNewOffset2 != long(uOffset2) ){  
		return 7197564;
	}
	return 0; 
}

uint32_t AsuUnpackU32LEBytes2( const void* data2 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	uint32_t value2 = (
		(uint32_t(data3[0]) << 0) |
		(uint32_t(data3[1]) << 8) |
		(uint32_t(data3[2]) << 16) |
		(uint32_t(data3[3]) << 24) );
	return value2;
}

uint16_t AsuUnpackU16LEBytes2( const void* data2 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	uint16_t value2 = (
		(uint16_t(data3[0]) << 0) |
		(uint16_t(data3[1]) << 8) );
	return value2;
}

int16_t AsuUnpackS16LEBytes2( const void* data2 )
{
	uint16_t val2 = AsuUnpackU16LEBytes2( data2 );
	return int16_t( DfhConvU64ToS64Safe2( val2 ) );
}
std::string AsuStrReplProvideSafeChars2( const void* data2, size_t num2 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	assert( num2 != size_t(-1) );
	char bfr2[32];
	std::string outp;
	for( size_t ii2 = 0; ii2 < num2; ii2++ ){
		uint8_t ch3 = data3[ii2];
		if( ch3 <= 127 ){
			char ch2 = static_cast<char>( ch3 );
			if( AsuIsPrintableChar2( ch2 ) && !std::strchr("\x20{}()[]\x22\x27\\",ch2) ){
				outp += ch2;
			}else{
				std::snprintf( bfr2, sizeof(bfr2), "\\x%02X", uint32_t(uint8_t(ch2)) );
				outp += bfr2;
			}
		}else{
			std::snprintf( bfr2, sizeof(bfr2), "\\x%02X", uint32_t(uint8_t(ch3)) );
			outp += bfr2;
		}
	}
	return outp;
}
std::string AsuStrReplProvideSafeChars3( const std::string& inp )
{
	return AsuStrReplProvideSafeChars2( inp.c_str(), inp.size() );
}
bool AsuIsPrintableChar2( char ch2 )
{
	return ( ch2 >= 0x20 && ch2 <= 0x7E );  
}

AsuRWCapacityBuffer6::AsuRWCapacityBuffer6()
{
	mData2.reserve( 0 );
	mData2.resize( 0 );
	mData2.shrink_to_fit();
}
void AsuRWCapacityBuffer6::AsuCBiReserve2( size_t uNumBytes2 )
{
	mData2.reserve( uNumBytes2 );
}
size_t AsuRWCapacityBuffer6::AsuCBiCapacity2()const
{
	return mData2.capacity();
}
bool AsuRWCapacityBuffer6::AsuCBiResize2( size_t uNumBytes2 )const
{
	assert( uNumBytes2 <= mData2.capacity() );
	mData2.resize( uNumBytes2 );
	mData2.shrink_to_fit();
	return 1L;
}


DfhQuad2<bool,std::string,uint64_t>
AsuProcessStandardStream2( std::FILE* stream3,
		size_t uElementSize2, uint64_t uMaxReadOrUntillEof3,
		const AsuRWCapacityBuffer6* cBfr2,
		const std::function<bool( const uint8_t*, size_t num2, std::string* err )>& calb5
		)
{
	assert( !!cBfr2 && !!uElementSize2 );
	assert( !!cBfr2->AsuCBiCapacity2() );
	assert( uElementSize2 <= cBfr2->AsuCBiCapacity2() );
	const bool bReadUntilEof3 = !!( uMaxReadOrUntillEof3 == uint64_t(-1) );
	

	const size_t uStrideBufferSize3 = (uElementSize2 * (cBfr2->AsuCBiCapacity2() / uElementSize2));
	if( !uStrideBufferSize3 ){
		return {0L,DfhSf2("Requested stride-buffer size %s was too small [mgMUeM]", {std::to_string(cBfr2->AsuCBiCapacity2()).c_str(),}), 0,};
	}
	assert( uElementSize2 <= uStrideBufferSize3 );
	cBfr2->AsuCBiResize2( uStrideBufferSize3 );
	{
		std::string err2;
		uint64_t uCountBytesReadd3 = 0;
		for( ; ; ){
			assert( cBfr2->AsuCBiGetSize2() == uStrideBufferSize3 );

			bool bFinalReadStep2 = 0L;
			size_t uNumToRead2 = cBfr2->AsuCBiGetSize2();
			if( uCountBytesReadd3 + uNumToRead2 >= uMaxReadOrUntillEof3 ){
				size_t uReduceBy2 = ((uCountBytesReadd3 + uNumToRead2) - uMaxReadOrUntillEof3);
				assert( uReduceBy2 <= uNumToRead2 );
				uNumToRead2 -= uReduceBy2;
				bFinalReadStep2 = 1L;
			}
			if( bFinalReadStep2 ){
				
				cBfr2->AsuCBiResize2( uNumToRead2 );
			}
			const size_t readd2 = std::fread( cBfr2->AsuCBiGetData2(), 1, cBfr2->AsuCBiGetSize2(), stream3 );
			assert( readd2 <= cBfr2->AsuCBiGetSize2() );
			uCountBytesReadd3 += readd2;
			if( readd2 < cBfr2->AsuCBiGetSize2() || bFinalReadStep2 ){
				if( readd2 ){
					const size_t uJunkSize2 = (readd2 % uElementSize2);
					if( uJunkSize2 ){
						assert( readd2 >= uJunkSize2 );
						cBfr2->AsuCBiResize2( readd2 - uJunkSize2 );
						DfhPf2(4,
							"LVDAU: WARN: Discarding %s junk-bytes at the end of sampled-data stream [KtLHFe]\n", {
								std::to_string(uJunkSize2).c_str(),});
					}else{
						cBfr2->AsuCBiResize2( readd2 );
					}
					if( !!cBfr2->AsuCBiGetSize2() ){ 
						if( !calb5( cBfr2->AsuCBiGetData2(), cBfr2->AsuCBiGetSize2(), &err2 ) ){
							return {0L,DfhSf2("Stride error B. [%s] [Hnmpek]", {err2.c_str(),} ),uCountBytesReadd3,};
						}
					}
				}else{
					
				}
				if( !!std::feof( stream3 ) ){
					return {1L,"OK. End of stream reached while reading data [aFcblO]",uCountBytesReadd3,};
				}
				if( !!std::ferror( stream3 ) ){
					return {0L,DfhSf2("Stream I/O error occured after reading %s bytes of data [uFCSIN]", {std::to_string(uCountBytesReadd3).c_str(),} ),uCountBytesReadd3,};
				}
				if( !bReadUntilEof3 && !bFinalReadStep2 ){
					return {0L,DfhSf2("Unknown stream I/O error occured after reading %s bytes of data [9NdYgN]", {std::to_string(uCountBytesReadd3).c_str(),} ),uCountBytesReadd3,};
				}
				return {1L,"",uCountBytesReadd3,};
			}else{
				
			}
			if( !calb5( cBfr2->AsuCBiGetData2(), cBfr2->AsuCBiGetSize2(), &err2 ) ){
				return {0L,DfhSf2("Stride error A. [%s] [C8aWJ0]", {err2.c_str(),} ),uCountBytesReadd3,};
			}
		}
		assert(!"LVDAU: Unreachable. [Js2qmd]");
		return {0L,"",0,};
	}
}


std::vector<uint8_t>
AsuWaveCreateFileHeaderPlaceholder2( const AsuWaveFmtDesc2& sFd2,
		uint64_t* uFileSizeOffsetOut2, uint64_t* uDataSizeOffsetOut2 )
{
	std::vector<uint8_t> outp;
	outp.resize( 44, 0 );
	std::memcpy( &outp[0], "RIFF", 4 );

	std::memcpy( &outp[4], "\xFF\xFF\xFF\xFF", 4 );  //file size, placeholder.
	std::memcpy( &outp[8], "WAVE", 4 );

	const uint16_t uBytePerBloc = sFd2.uNumChannels2 * sFd2.uBitsPerSample2 / 8;
	const uint32_t uBytePerSec  = sFd2.uFrequency2 * uBytePerBloc;
	std::memcpy( &outp[12], "fmt\x20", 4 );  //FormatBlocID, "fmt "
	std::memcpy( &outp[16], AsuConvU32ToLEBytes2( 16 ).data(), 4 );  
	std::memcpy( &outp[20], AsuConvU16ToLEBytes2( sFd2.uAudioFormat2 ).data(), 2 );  
	std::memcpy( &outp[22], AsuConvU16ToLEBytes2( sFd2.uNumChannels2 ).data(), 2 );  
	std::memcpy( &outp[24], AsuConvU32ToLEBytes2( sFd2.uFrequency2   ).data(), 4 );  
	std::memcpy( &outp[28], AsuConvU32ToLEBytes2( uBytePerSec ).data(), 4 );  
	std::memcpy( &outp[32], AsuConvU16ToLEBytes2( uBytePerBloc ).data(), 2 );  
	std::memcpy( &outp[34], AsuConvU16ToLEBytes2( sFd2.uBitsPerSample2 ).data(), 2 );  
	std::memcpy( &outp[36], "data", 4 );  //DataBlocID
	std::memcpy( &outp[40], "\x00\x00\x00\x00", 4 );  //DataSize, placeholder.

	if( uFileSizeOffsetOut2 )
		*uFileSizeOffsetOut2 = 4;
	if(uDataSizeOffsetOut2)
		*uDataSizeOffsetOut2 = 40;
	return outp;
}

std::string AsuGetCompilerString2()
{
	std::string outp = "Unknown";
	#ifdef __GNUC__ 
		outp  = "GCC";
	#endif
	#ifdef __clang__ 
		outp = "Clang";
	#endif
	#ifdef _MSC_VER  
		outp = "MSVC";
	#endif
	return outp;
}
bool AsuIsWithinInterval2( double inp, double fLo, double fHi, const char* flags2 )
{
	assert( fLo <= fHi );
	flags2 = flags2 ? flags2 : "";
	const bool bLClosed = ( flags2[0] == 'c');
	const bool bRClosed = ( flags2[0] && flags2[1] == 'c');
	if( bLClosed ){
		if( !(inp >= fLo) )
			return 0L;
	}else{
		if( !(inp > fLo) )
			return 0L;
	}
	if( bRClosed ){
		if( !(inp <= fHi) )
			return 0L;
	}else{
		if( !(inp < fHi) )
			return 0L;
	}
	return 1L;
}