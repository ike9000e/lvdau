#include "asu_aud_out_file.hh"
#include <cstdlib>  
#include <cassert>  
#include <limits>  
#include <cstring> 
#include <algorithm>
#include "dfh_crt_fix.hh"
#include "dfh_core.hh"
#include "dfh_cma_average.hh"

AsuWaveFileOutput2::AsuWaveFileOutput2( const AsuWFOParams7& inp )
	: mWFOConf2( inp )
{
}
AsuWaveFileOutput2::~AsuWaveFileOutput2()
{
	if( mOpenedFile2 ){
		this->AsuWOiFinalizeOutputFile2();
	}
}
DfhQuad2<bool,std::string> AsuWaveFileOutput2::
AsuWOiInitializeOutputFile2( const char* szOutpFileName2, const char* flags2_u_ )
{
	assert( !!szOutpFileName2 && !!*szOutpFileName2 );
	assert( !mOpenedFile2 );

	if( AsuAnyCStr2( szOutpFileName2, {"stdout_","-","stdio_",},"") ){
		mUsingStdoutStream2 = 1L;
		mOpenedFile2 = stdout;
		DfhSetStdStreamBinaryMode2( mOpenedFile2 );
	}else{
		mOpenedFile2 = std::fopen( szOutpFileName2, "wb");
		if( !mOpenedFile2 ){
			return {0L, DfhSf2("File open failed, RW [%s] [1SaMq1]", {AsuConvStdErrorCodeToStr2(errno,"").c_str(),} ),};
		}
	}
	return {1L,"",};
}
void AsuWaveFileOutput2::AsuWOiSetWaveFormat2( const AsuWaveFmtDesc2& inp )
{
	assert( !!inp );
	
	mWaveFd2.uFrequency2     = inp.uFrequency2;
	mWaveFd2.uNumChannels2   = 1;  
	mWaveFd2.uAudioFormat2   = ASU_E5_WaveAudioFormatPCMInteger2;
	mWaveFd2.uBitsPerSample2 = 16;
}

bool AsuWaveFileOutput2::AsuWOiFinalizeOutputFile2()
{
	mCurrAudioBuffer2.clear();
	if( mOpenedFile2 ){
		if( !mUsingStdoutStream2 || mWFOConf2.bUpdateStdoutFileHeader3 ){
			DfhPf2(8,"LVDAU: Updating file size and sampled-data size [MOaLkb]\n",{});
			if( mOffsToFileSize2 ){
				if( !AsuFseek2( mOpenedFile2, mOffsToFileSize2 ) ){
					assert( mTotalBytesInFile2 <= uint32_t(-1) );
					std::fwrite( AsuConvU32ToLEBytes2( uint32_t( mTotalBytesInFile2 ) ).data(),
						1, 4, mOpenedFile2 );
					DfhPf2(8,"LVDAU: Updated file size to %s bytes [Cpaw8v]\n", {
						std::to_string(mTotalBytesInFile2).c_str(),});
				}else{
					DfhPf2(8,"LVDAU: Couldn't update stream file size [49bVBV]\n",{});
				}
			}
			if( mOffsToDataSize2 ){
				if( !AsuFseek2( mOpenedFile2, mOffsToDataSize2 ) ){
					assert( mTotalDataBytesWrtn2 <= uint32_t(-1) );
					std::fwrite( AsuConvU32ToLEBytes2( uint32_t( mTotalDataBytesWrtn2 ) ).data(),
						1, 4, mOpenedFile2 );
				}else{
					DfhPf2(8,"LVDAU: Couldn't update stream sampled-data size [z0TinO]\n",{});
				}
			}
		}
		if( !mUsingStdoutStream2 ){
			std::fclose( mOpenedFile2 );
		}
		mOpenedFile2 = nullptr;
		return 1L;
	}
	return 0L;
}
bool AsuWaveFileOutput2::AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp )
{
	assert( !!mOpenedFile2 );
	if( !mHadHeaderWritten2 ){
		assert( !!mWaveFd2 );
		const std::vector<uint8_t> bytes2 = AsuWaveCreateFileHeaderPlaceholder2( mWaveFd2, &mOffsToFileSize2, &mOffsToDataSize2 );
		assert( !bytes2.empty() );
		assert( !!mOffsToFileSize2 );
		assert( !!mOffsToDataSize2 );
		const size_t uWritten2 = std::fwrite( bytes2.data(), 1, bytes2.size(), mOpenedFile2 );
		if( uWritten2 != bytes2.size() ){
			DfhPf2(2,"LVDAU: ERROR: Failed writting wave file header, %s bytes [qaxNFA]", {
					std::to_string(bytes2.size()).c_str(),});
			return 0L;
		}
		mTotalBytesInFile2 += bytes2.size();
		mHadHeaderWritten2 = 1L;
	}
	const uint64_t uSampleSize2 = sizeof( inp.pSamples3[0] );
	assert( uSampleSize2 == 2 );
	const uint64_t uNumBytesInBuffer2 = ( uSampleSize2 * inp.uNumSamples3);
	mCurrAudioBuffer2.resize( uNumBytesInBuffer2 );

	for( size_t ii2 = 0; ii2 < inp.uNumSamples3; ii2++ ){
		uint8_t* pSamp2 = &mCurrAudioBuffer2[ ii2 * uSampleSize2 ];
		std::memcpy( pSamp2, AsuConvU16ToLEBytes2( inp.pSamples3[ii2] ).data(), uSampleSize2 );
	}
	const size_t uWritten3 = std::fwrite( mCurrAudioBuffer2.data(), 1, mCurrAudioBuffer2.size(), mOpenedFile2 );
	if( uWritten3 != mCurrAudioBuffer2.size() ){
		DfhPf2(2,"LVDAU: ERROR: Failed writting %s bytes to file [X1FEwk]",
			{ std::to_string(mCurrAudioBuffer2.size()).c_str(),});
		return 0L;
	}
	mTotalDataBytesWrtn2 += inp.uNumSamples3 * uSampleSize2;
	mTotalBytesInFile2   += inp.uNumSamples3 * uSampleSize2;
	return 1L;
}


AsuSilencesLogger6::~AsuSilencesLogger6()
{
	this->finalizeLogFile2();
}
bool AsuSilencesLogger6::
initializeLogFile2( const char* filename2, const char* flags2 )
{
	mOpenedFile3 = std::fopen( filename2, "wb");
	if( !mOpenedFile3 ){
		DfhPf2(2,"LVDAU: ERROR: File open failed (logging) [%s] [6DB1fE]", { AsuConvStdErrorCodeToStr2(errno,"").c_str(),});
		return 0L;
	}
	return 1L;
}
bool AsuSilencesLogger6::finalizeLogFile2()
{
	if( mOpenedFile3 ){
		std::fclose( mOpenedFile3 );
		mOpenedFile3 = nullptr;
	}
	return 1L;
}

void AsuSilencesLogger6::setReferenceFileName2( const char* szRefFname2 )
{
	assert( szRefFname2 && *szRefFname2 );
	mReferenceFileName2 = szRefFname2;
}
void AsuSilencesLogger6::AsuTLiAddAudioInterval2( const AsuAudioInterval7& intrvl3 )
{
	assert( !!mOpenedFile3 );
	std::string text2;
	if( !mNumLogsWritten2 ){
		
		
		
		
		text2 += "ffconcat version 1.0\n\n";
	}
	text2 += DfhSf2(
		"file \x22%s\x22\n"
		"inpoint %s\n"
		"outpoint %s\n\n",{
			( !mReferenceFileName2.empty() ? mReferenceFileName2.c_str() : "unknown_t4gvy5o.wav" ),
			DfhConvFloatToStr2(intrvl3.fStartSecs2, 0, 12, ""),
			DfhConvFloatToStr2(intrvl3.fEndSecs2, 0, 12, ""),
	});
	const size_t uWritten2 = std::fwrite( text2.c_str(), 1, text2.size(), mOpenedFile3 );
	assert( uWritten2 == text2.size() );
	mNumLogsWritten2 += 1;
}