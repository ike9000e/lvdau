#pragma once
#include <cstdio>  
#include <cinttypes>  
#include <string>
#include <vector>
#include <functional>   
#include "asu_intrf.hh"

struct AsuWFOParams7{
	bool bUpdateStdoutFileHeader3 = 0L;
};

struct AsuWaveFileOutput2 : AsuReceiverFilterBase2, AsuWriteOutStreamBase2 {
	AsuWaveFileOutput2() = delete;
	AsuWaveFileOutput2( const AsuWFOParams7& inp );
	AsuWaveFileOutput2( const AsuWaveFileOutput2& ) = delete;
	~AsuWaveFileOutput2();
	
	bool AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp )override;
	auto AsuWOiInitializeOutputFile2( const char* szOutpFileName2, const char* flags2 ) -> DfhQuad2<bool,std::string> override;
	void AsuWOiSetWaveFormat2( const AsuWaveFmtDesc2& inp )override;
	bool AsuWOiFinalizeOutputFile2()override;
private:
	std::FILE*            mOpenedFile2 = nullptr;
	std::vector<uint8_t>  mCurrAudioBuffer2;
	uint64_t              mTotalDataBytesWrtn2 = 0, mTotalBytesInFile2 = 0;
	uint64_t              mOffsToFileSize2 = 0, mOffsToDataSize2 = 0;
	AsuWaveFmtDesc2       mWaveFd2;
	bool                  mHadHeaderWritten2 = 0L;
	bool                  mUsingStdoutStream2 = 0L;
	AsuWFOParams7         mWFOConf2;
};

struct AsuSilencesLogger6 : AsuTextLogger6 {
	AsuSilencesLogger6() = default;
	~AsuSilencesLogger6();
	void AsuTLiAddAudioInterval2( const AsuAudioInterval7& inp )override;
	
	bool initializeLogFile2( const char* filename2, const char* flags2 );
	bool finalizeLogFile2();
	void setReferenceFileName2( const char* filename3 );
private:
	std::FILE* mOpenedFile3 = nullptr;
	uint64_t mNumLogsWritten2 = 0;
	std::string mReferenceFileName2;
};
