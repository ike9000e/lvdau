#include "dfh_reinterpolate.hh"
#include <cassert>  

#include <cstring> 
#include <limits>
#include <cmath>  


double DfhMirrorScalarOnPivot2( double inp, double ffPivot )
{
	return ((inp - ( ffPivot * 2.0 )) * -1.0);
}


double DfhUnitAmplifySineSCurvePart2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	double yyy = (( std::sin( (xxx + 1.5) * DfhGetMathPiValue2() ) + 1.0 ) / 2.0);
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifySCurveNWSEQuadrants2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	if( !xxx || xxx == 1.0 ){
		return xxx;
	}
	double yyy = [xxx]()->double{
		if( xxx <= 0.5 ){
			return ((std::sqrt( 1.0 - std::pow( ((xxx * 2.0) - 1.0), 2.0))) / 2.0 );
		}else{
			return ((-( std::sqrt( 1.0 - std::pow( ((xxx * 2.0) - 1.0), 2.0 )) - 1.0 ) / 2.0 ) + 0.5);
		}
	}();
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifySmoothStep2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	double yyy = ( (xxx*xxx) / ( (xxx*xxx) + ( (1.0 - xxx) * (1.0 - xxx) ) ) );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}


double DfhUnitAmplifyQuarterSine2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	const double yyy = std::sin( xxx * (DfhGetMathPiValue2()/2.0) );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyFlippedQuarterSine2( double fInp2 )
{
	assert( fInp2 >= 0.0 && fInp2 <= 1.0 );
	if( !fInp2 ){   
		return 0.0;
	}
	fInp2 = DfhMirrorScalarOnPivot2( fInp2, 0.5 );
	double fOutp2 = std::sin( fInp2 * (DfhGetMathPiValue2()/2.0) );
	fOutp2 = DfhMirrorScalarOnPivot2( fOutp2, 0.5 );
	assert( fOutp2 >= 0.0 && fOutp2 <= 1.0 );
	return fOutp2;
}

double DfhUnitAmplifyCircleNWQuadrant2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );

	double yyy = ( std::sqrt( 1.0 - ( (xxx - 1.0) * (xxx - 1.0) ) ) );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyCircleSEQuadrant2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	if( !xxx ){    
		return 0.0;
	}
	double yyy = -( std::sqrt( 1.0 - ( xxx * xxx ) ) - 1.0 );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyXPower2( double xxx, double fExponent2 )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	const double yyy = std::pow( xxx, fExponent2 );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyFlippedXPower2( double xxx, double fExponent2 )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	const double yyy = ( (std::pow( (xxx - 1.0), fExponent2 ) * -1.0) + 1.0 );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifySquareRoot2( double xxx )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	if( !xxx || xxx == 1.0 ){
		return xxx;
	}
	const double yyy = std::sqrt( xxx );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyNthRoot2( double xxx, double fNthRoot2 )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	if( !xxx || xxx == 1.0 ){
		return xxx;
	}
	const double yyy = std::pow( xxx, (1.0 / fNthRoot2) );
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}

double DfhUnitAmplifyFlippedNthRoot2( double xxx, double fNthRoot2 )
{
	assert( xxx >= 0.0 && xxx <= 1.0 );
	if( !xxx || xxx == 1.0 ){
		return xxx;
	}
	const double yyy = ((std::pow( (1.0 - xxx), (1.0 / fNthRoot2) ) * -1.0) + 1.0);
	assert( yyy >= 0.0 && yyy <= 1.0 );
	return yyy;
}
