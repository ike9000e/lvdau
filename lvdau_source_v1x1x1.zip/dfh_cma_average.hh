#pragma once
#include <utility>   
#include <cstddef>  

void DfhUnitTests4();


template<class Tvx>
struct DfhCMAAverage2
{
	DfhCMAAverage2();
	auto          update2( Tvx inp ) -> DfhCMAAverage2&;
	Tvx           getAvg()const;
	auto          setAvg( const Tvx inp ) -> DfhCMAAverage2&;
	bool          isValid()const {return mIsValid3;}
	static auto   getAllowedMinMax() -> const std::pair<Tvx,Tvx>&;
	static size_t getDigitsCount();
private:
	
	;             template< typename Txx = Tvx, typename std::enable_if< std::is_floating_point<Txx>::value,int>::type Tdummy = 0 >
	auto          update9( Tvx inp ) -> DfhCMAAverage2&;
	;             template< typename Txx = Tvx, typename std::enable_if< ! std::is_floating_point<Txx>::value,int>::type Tdummy = 0 >
	auto          update9( Tvx inp ) -> DfhCMAAverage2&;
	static auto   getAllowedMinMax9() -> std::pair<Tvx,Tvx>;
private:
	Tvx                       mAvg2 = 0, mCount = 0;
	Tvx                       mCumulatedRemainder = 0;
	bool                      mIsValid3 = 1L;
	static std::pair<Tvx,Tvx> mAllowedRange;
};