#include "asu_entrypoint.hh"

const char* AsuUsageStr2 =
	"LVDAU - Low Volume Detection - Audio Utility    \n"
	"= = = = = = = = = = = = = = = = = = = = = = = = \n"
	"                                                \n"
	"USAGE                                            \n"
	"-----                                            \n"
	"    -ifn <FILE>                                  \n"
	"        Input file for processing.                         \n"
	"        The only supported file format is WAVE (.wav).       \n"
	"        The only supported sample formats within the WAVE file are: \n"
	"            * PCM 16-bit signed integer (pcm_s16le)                 \n"
	"            * PCM 8-bit unsigned integer (pcm_u8)                   \n"
	"        To read from the standard input (STDIN) set it to \x22-\x22 \n"
	"                                                                    \n"
	"    -ofn <FILE>                                                      \n"
	"        Output file for processed audio data.                        \n"
	"        The only possible output format is WAVE (.wav).               \n"
	"        The only possible sample format is pcm_s16le, mono.          \n"
	"        To write to the standard output (STDOUT) set it to \x22-\x22 \n"
	"                                                      \n"
	"    -silence_threshold <VALUE>                        \n"
	"        Silence detetection parameter, threshold.     \n"
	"        The lower value, the lower volume will be considered \n"
	"        as the silence. Value must be between 0.0 and 1.0. \n"
	"        Typical \x22""silences\x22 should be below 0.2.       \n"
	"        Default: silence_threshold_default_7CDeyO     \n"
	"                                             \n"
	"    -min_silence_duration <SECONDS>                          \n"
	"        Silence detetection parameter, minimum duration.     \n"
	"        How many time of the silence there must be to        \n"
	"        consider it for processing, f.e. removal.            \n"
	"        Default: min_silence_duration_default_7ReSog seconds \n"
	"                                                             \n"
	"    -shrink_to <VALUE>                                       \n"
	"        Fraction value in the range from 0.0 to 1.0 to shrink,  \n"
	"        time compress, every detected silence to.               \n"
	"        For example, 0.5 shrinks the silence to 50 percent.     \n"
	"                                                                \n"
	"    -probe_duration <SECONDS>                \n"
	"        Advanced. Silence detetection parameter, probe duration.\n"
	"        It is recommended to leave the default.\n"
	"        Specific to the method used by the code.\n"
	"        Value in seconds of how many audio samples to use to \n"
	"        determine if the audio is silent.\n"
	"        Default: probe_duration_default_enkPhM seconds  \n"
	"                                                        \n"
	"    -loglevel <VALUE>                                             \n"
	"        Set log-level of the program.                             \n"
	"        Possible values: error, warning or debug.                 \n"
	"        Can be set to a numerical value 0 to suppress most of \n"
	"        the messages.                      \n"
	"                                           \n"
	"    -fshow_params                            \n"
	"        If present, shows the summary of program configuration.   \n"
	"        Use -fshow_params_only instead to exit afterwards.        \n"
	"                                           \n"
	"    -finfo_only                            \n"
	"        If present, shows file information only, then exits.\n"
	"                                           \n"
	"    -fshow_build_info                      \n"
	"    -main_buffer_size <NUM_BYTES>          \n"
	"    -fno_unit_tests                        \n"
	"    -fignore_leading_silence               \n"
	"    -fignore_middle_silences               \n"
	"    -fignore_trailing_silence              \n"
	"                                           \n"
	"    -fupdate_stdout                 \n"
	"        Workaround when writting the data to STDOUT and the data is not preocessed.\n"
	"        Forces update of the Wave header, at the finalization step, as-if \n"
	"        the stream was a disk file. Valid only in STDOUT mode. Shouldn't be used\n"
	"        normally, when passing the data via the pipe.\n"
	"        May cause noticeable corruption at the end of the audio stream.\n"
	"                                           \n"
	"    -silence_log_file <FILE>                               \n"
	"        Additional output text file that will have all detected silences.\n"
	"        Format used is Ffmpeg's ffconcat.                              \n"
	"                                           \n"
	"    -silence_ref_file <NAME>                \n"
	"        For use with '-silence_log_file'. Specify file name that  \n"
	"        is inserted inside the log file. Otherwise used is that from '-ifn'.\n"
	"                                           \n"
	"    -help                                  \n"
	"        Shows this help message.           \n"
	"                                           \n"
	"";

int32_t AsuAppParams2::convLogLevelNameToNumber2( const char* inp )
{
	
	static const std::array<DfhQuad2<const char*,int32_t>,3> aErrorLevelNames3 = {{
		{"error",   2,},
		{"warning", 4,},
		{"debug",   8,},
	}};
	for( auto ir2 = aErrorLevelNames3.begin(); ir2 != aErrorLevelNames3.end(); ++ir2 ){
		if( !std::strcmp( ir2->first, inp ) ){
			return ir2->second;
		}
	}
	return 65535;
}

std::string AsuAppParams2::getAppParamsAsString2( const char* szTabs2 )const
{
	std::string outp;
	outp += DfhSf2("%s* Log-level: %u\n", { szTabs2, this->nAppLogLevel2,});
	outp += DfhSf2("%s* Main buffer size: %u\n", { szTabs2, this->uMainBufferSize2,});
	outp += DfhSf2("%s* Run unit tests: [%s]\n", { szTabs2, (this->bRunUnitTests2 ? "Yes" : "No"),});
	outp += DfhSf2("%s* Show info only: [%s]\n", { szTabs2, (this->bInfoOnly2 ? "Yes" : "No"),});
	outp += DfhSf2("%s* Show params: [%s]\n", { szTabs2, (this->bShowProgramParams2 ? "Yes" : "No"),});
	const std::string idn2 = DfhSplitPath2(this->srInputFn2)[0];
	const std::string odn2 = DfhSplitPath2(this->srOutpFn2)[0];
	outp += DfhSf2("%s* Input file name: [%s%s]\n", { szTabs2, (idn2.empty()?"":"... "), DfhSplitPath2(this->srInputFn2)[1], });
	outp += DfhSf2("%s* Output file name: [%s%s]\n", { szTabs2, (odn2.empty()?"":"... "), DfhSplitPath2(this->srOutpFn2)[1], });
	outp += DfhSf2("%s* Shrink to: %s\n", { szTabs2, DfhConvFloatToStr2(this->fShrinkFractionTo2,0,6,""),});

	return outp;
}
void AsuShowHelp2()
{
	static const AsuSilenceDefinition2 sDfltSilDef2;
	const std::vector<std::pair<std::string,std::string> > aSeRepl2 = {
		{"silence_threshold_default_7CDeyO",    std::to_string(sDfltSilDef2.fSilenceThresholdFrac2),},
		{"probe_duration_default_enkPhM",       std::to_string(sDfltSilDef2.fProbeDurationSecs2),},
		{"min_silence_duration_default_7ReSog", std::to_string(sDfltSilDef2.fMinSilenceDurationSecs2),},
	};
	std::string hlp2 = AsuUsageStr2;
	for( auto ir2 = aSeRepl2.begin(); ir2 != aSeRepl2.end(); ++ir2 ){
		hlp2 = DfhStrReplace3( hlp2.c_str(), hlp2.size(),
			ir2->first.c_str(), ir2->first.size(),
			ir2->second.c_str(), ir2->second.size(),
			size_t(-1), "" );
	}
	DfhPf2(1,"\n%s",{ hlp2.c_str(),});
}

int main( const int argc, const char*const* argv )
{
	{

	}{

	}{

	}{
		
	}{


		
		
	}{

	}
	AsuAppParams2 sApp2;
	for( int ii2=1; ii2 < argc; ii2++ ){
		const char* ar2 = argv[ii2];
		const char* ar3 = (ii2+1 < argc ? argv[ii2+1] : "");
		if(0){
		}else if( AsuAnyCStr2( ar2, {"-ifn",},"") ){
			sApp2.srInputFn2 = ar3;
		}else if( AsuAnyCStr2( ar2, {"-ofn",},"") ){
			sApp2.srOutpFn2 = ar3;
		}else if( AsuAnyCStr2( ar2, {"-help","--help","-?","/?","-h","/h",},"") ){
			sApp2.bShowHelp2 = 1L;
			break;
		}else if( AsuAnyCStr2( ar2, {"-finfo_only",},"") ){
			sApp2.bInfoOnly2 = 1L;
		}else if( AsuAnyCStr2( ar2, {"-fno_unit_tests",},"") ){
			sApp2.bRunUnitTests2 = 0L;
		}else if( AsuAnyCStr2( ar2, {"-num_frames_show",},"") ){
			if( !std::strcmp( ar3, "-1") ){
				sApp2.uNumFramesShow2 = uint64_t(-1);
			}else{
				sApp2.uNumFramesShow2 = std::strtoull( ar3, nullptr, 10 );
			}
		}else if( AsuAnyCStr2( ar2, {"-loglevel",},"") ){
			if( *ar3 ){
				if( DfhIsAlpha2( *ar3 ) ){
					sApp2.nAppLogLevel2 = AsuAppParams2::convLogLevelNameToNumber2( ar3 );
				}else if( !std::strcmp( ar3, "0")){
					sApp2.nAppLogLevel2 = 0;
				}else{
					sApp2.nAppLogLevel2 = std::max<int32_t>( 1, std::atoi( ar3 ) );
				}
			}
		}else if( AsuAnyCStr2( ar2, {"-silence_threshold",},"") ){
			sApp2.sSilDef3.fSilenceThresholdFrac2 = (
				std::max<double>( 0.0,
					std::min<double>( 1.0, std::atof( ar3 ))));
		}else if( AsuAnyCStr2( ar2, {"-probe_duration",},"") ){
			sApp2.sSilDef3.fProbeDurationSecs2 = std::max<double>( std::atof( ar3 ), std::numeric_limits<double>::epsilon() );
		}else if( AsuAnyCStr2( ar2, {"-min_silence_duration",},"") ){
			sApp2.sSilDef3.fMinSilenceDurationSecs2 = std::atof( ar3 );
		}else if( AsuAnyCStr2( ar2, {"-fignore_leading_silence",},"") ){
			sApp2.sSilDef3.bOmitLeadingSience2 = 1L;
		}else if( AsuAnyCStr2( ar2, {"-fignore_middle_silences",},"") ){
			sApp2.sSilDef3.bOmitMiddleSiences2 = 1L;
		}else if( AsuAnyCStr2( ar2, {"-fignore_trailing_silence",},"") ){
			sApp2.sSilDef3.bOmitTrailingSience2 = 1L;
		}else if( AsuAnyCStr2( ar2, {"-shrink_to",},"") ){
			sApp2.fShrinkFractionTo2 = std::max<double>( std::atof( ar3 ), std::numeric_limits<double>::epsilon() );
			sApp2.fShrinkFractionTo2 = std::min<double>( sApp2.fShrinkFractionTo2, 1.0 );
		}else if( AsuAnyCStr2( ar2, {"-fshow_params",},"") ){
			sApp2.bShowProgramParams2 = 1;
		}else if( AsuAnyCStr2( ar2, {"-fshow_params_only",},"") ){
			sApp2.bShowProgramParams2 = 2;
		}else if( AsuAnyCStr2( ar2, {"-fshow_build_info",},"") ){
			sApp2.bShowBuildInfo2 = 1L;
		}else if( AsuAnyCStr2( ar2, {"-main_buffer_size",},"") ){
			if( *ar3 ){
				sApp2.uMainBufferSize2 = std::min<size_t>( (std::max<size_t>( 16, std::atoi( ar3 ))), std::numeric_limits<int32_t>::max() );
			}
		}else if( AsuAnyCStr2( ar2, {"-silence_log_file",},"") ){
			sApp2.srSilencesLogFn2[0] = ar3;
		}else if( AsuAnyCStr2( ar2, {"-silence_ref_file",},"") ){
			sApp2.srSilencesLogFn2[1] = ar3;
		}else if( AsuAnyCStr2( ar2, {"-fupdate_stdout",},"") ){
			sApp2.sWfoCfg2.bUpdateStdoutFileHeader3 = 1L;
		}
	}
	DfhPokeLogLevel2( sApp2.nAppLogLevel2, -1, nullptr ); 
	if( argc <= 1 ){
		sApp2.bShowHelp2 = 1L;
	}
	if( sApp2.bRunUnitTests2 ){   
		DfhPf2(8,"LVDAU: Running unit tests...\n", {});
		DfhUnitTests4();
		DfhUnitTests3();
		AsuUnitTests2();
	}
	if( sApp2.bShowHelp2 ){
		AsuShowHelp2();
		if( argc <= 1 ){
			DfhPf2(4,"LVDAU: WARN: No command line arguments provided.\n",{});
		}
		return 2;
	}
	if( sApp2.bShowBuildInfo2 ){  
		DfhPf2(1,"LVDAU: Build date: %s\n", { __DATE__,});
		DfhPf2(1,"       Pointer size: %d\n", { int(sizeof(void*)),});
		DfhPf2(1,"       Compiler: %s\n", { AsuGetCompilerString2(),});
		return 2;
	}
	{
		DfhPf2((sApp2.bShowProgramParams2 ? 1 : 8),  
			"LVDAU: Program Configuration:\n%s",{
			sApp2.getAppParamsAsString2("\x20\x20\x20\x20\x20\x20\x20").c_str(),});
		if( sApp2.bShowProgramParams2 > 1 ){  
			return 2;
		}
	}
	if( !*sApp2.srInputFn2.c_str() ){
		DfhPf2(2,"LVDAU: ERROR: No input file name provided (-ifn) [iuYg66v]\n", {});
		return 151;
	}
	if( !*sApp2.srOutpFn2.c_str() ){
		DfhPf2(2,"LVDAU: ERROR: No output file name provided (-ofn) [dkhHM6]\n",{});
		
		return 154;
	}
	bool bIsStdinInputMode2 = 0L;
	std::FILE* instream2 = nullptr;
	std::shared_ptr<void> sbrm2( 0, [&]( void* ){
		if( instream2 && !bIsStdinInputMode2 ){
			std::fclose(instream2);
			instream2 = nullptr;
		}
	});
	if( AsuAnyCStr2( sApp2.srInputFn2.c_str(), {"-","stdin_","stdio_",},"") ){
		DfhPf2(6,"LVDAU: Requested input mode is STDIN.\n",{});
		assert( stdin );
		DfhSetStdStreamBinaryMode2( stdin );
		instream2 = stdin;
		bIsStdinInputMode2 = 1L;
	}else{
		instream2 = std::fopen( sApp2.srInputFn2.c_str(), "rb" );
		if( !instream2 ){
			DfhPf2(2,"LVDAU: File open failed. [%s] [I4Evm3]\n", { AsuConvStdErrorCodeToStr2(errno,"").c_str(),});
			return 152;
		}
		DfhPf2(8,"LVDAU: Input file opened successfully.\n",{});
	}
	{
		AsuWaveFileOutput2 sWaveOutFile3( sApp2.sWfoCfg2 );  
		if( !sApp2.bInfoOnly2 ){
			auto rs2 = sWaveOutFile3.AsuWOiInitializeOutputFile2( sApp2.srOutpFn2.c_str(),"o");
			assert( !!*rs2 );
		}
		AsuAudShrinkageDef7 sShrinkDef2;
		sShrinkDef2.eASMethod2       = ASU_E9_ContractionByTimeCompress2;
		sShrinkDef2.fShrinkFraction2 = sApp2.fShrinkFractionTo2;  

		AsuAudioShrinkageFilter2 cAudShrinkFilter2( sShrinkDef2 );
		cAudShrinkFilter2.AsuAFiSetAudioReceiver2( &sWaveOutFile3 );

		std::shared_ptr<AsuSilencesLogger6> cSilLogger2;

		AsuSilenceDetectorFilter2 cSilDetector2( sApp2.sSilDef3 );
		cSilDetector2.AsuAFiSetAudioReceiver2( &cAudShrinkFilter2 );

		if( !!*sApp2.srSilencesLogFn2[0].c_str() ){  
			cSilLogger2.reset( new AsuSilencesLogger6 );
			cSilLogger2->initializeLogFile2( sApp2.srSilencesLogFn2[0].c_str(), "");
			if( !!*sApp2.srSilencesLogFn2[1].c_str() ){   
				cSilLogger2->setReferenceFileName2( sApp2.srSilencesLogFn2[1].c_str() );
			}else{
				cSilLogger2->setReferenceFileName2( sApp2.srInputFn2.c_str() );
			}
			cSilDetector2.setSilenceLogger2( cSilLogger2.get() );
		}
		AsuReworkWSParams7 rwp2;
		rwp2.stream2            = instream2;
		rwp2.pAudFilter4        = &cSilDetector2;
		rwp2.uStrideBufferSize2 = sApp2.uMainBufferSize2;  
		rwp2.bDiskFileMode2     = !bIsStdinInputMode2;
		rwp2.bDryRunMode2       = !!sApp2.bInfoOnly2;
		rwp2.uNumSamplesShow3   = 0;
		rwp2.pAudOutStream2     = &sWaveOutFile3;
		rwp2.calbOnMoreWaveInfo2 = [&]( const AsuReworkWSCalbParams6& in2 )->bool{
				if( sApp2.bInfoOnly2 ){   
					assert( in2.pWaveInfo2 );
					AsuWaveShowInfo2( *in2.pWaveInfo2, "");
					return 0L;  
				}
				return 1L;
		};
		DfhPf2(8,"LVDAU: Reading data...\n",{});
		
		auto rs3 = AsuReworkWaveStream2( rwp2 );
		DfhPf2(8,"LVDAU: Stream processing result: [%s]\n", { (*rs3 ? "Success" : "Error"),});
		if( !*rs3 ){
			DfhPf2(2,"LVDAU: ERROR: %s [a8yJp6]\n",{ rs3.second.c_str(),});
		}
		cAudShrinkFilter2.AsuAFiFinalize2();
		sWaveOutFile3.AsuWOiFinalizeOutputFile2();
		if( !*rs3 ){
			return 155;
		}
	}
	DfhPf2(8,"LVDAU: Program exit.\n",{});
	return 0;
}