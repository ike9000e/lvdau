#pragma once

void DfhSetStdStreamBinaryMode2( void* std_stream_ );