#include "asu_af_shrinkage.hh"
#include <cassert>  
#include "dfh_reinterpolate.hh"
#include "dfh_cma_average.hh"

AsuAudioShrinkageFilter2::
AsuAudioShrinkageFilter2( const AsuAudShrinkageDef7& inp )
	: mShrinkConf2( inp )
{
	assert( (inp.fShrinkFraction2 >= 0.0 && inp.fShrinkFraction2 <= 1.0) || inp.fShrinkDuration2 >= 0 );
	assert( !!inp.eASMethod2 && !!inp.eAPSelect2 );
}
bool AsuAudioShrinkageFilter2::isAudioFeedProcessed2( AsuAudFeedType2 eAFType2 )const
{
	if( mShrinkConf2.eAPSelect2 == ASU_E10_SelectSpoiledPart2 ){
		return eAFType2 == ASU_E8_AFTypeSpoiled2;
	}else if( mShrinkConf2.eAPSelect2 == ASU_E10_SelectPristinePart2 ){
		return eAFType2 == ASU_E8_AFTypePristine2;
	}else if( mShrinkConf2.eAPSelect2 == ASU_E10_SelectBothParts2 ){
		return 1L;
	}else{
		assert(!"Bad branching [rNu8Km]");
	}
	return 0L;
}
bool AsuAudioShrinkageFilter2::
AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& afp2 )
{
	assert( !!mReceiver3 );
	if( this->isAudioFeedProcessed2( afp2.eAFType2 ) ){
		if( mShrinkConf2.eASMethod2 == ASU_E9_ContractionByRemove2 ){
			
			assert( !!mContractionBfr2.empty() );
		}else if( mShrinkConf2.eASMethod2 == ASU_E9_ContractionByTimeCompress2 ){
			std::copy( afp2.pSamples3, (afp2.pSamples3 + afp2.uNumSamples3),
					std::back_inserter(mContractionBfr2) );
			if( mContractionBfr2.size() >= mShrinkConf2.uMinWorksetSize2 ){
				this->shrinkAndSendCurrentBuffer2();
			}
		}else{
			assert(!"Bad branching [o3SqVZ]");
		}
		return 1L;
	}else{ 
		if( !mContractionBfr2.empty() ){
			this->shrinkAndSendCurrentBuffer2();
		}
		return mReceiver3->AsuRFiFeedAudioData2( afp2 );
	}
}
bool AsuAudioShrinkageFilter2::AsuAFiFinalize2()
{
	DfhPf2(6,"LVDAU: Finalizing shrinkage filter. Last buffer size: %s\n",{
		std::to_string( mContractionBfr2.size() ).c_str(),});
	if( !mContractionBfr2.empty() ){
		this->shrinkAndSendCurrentBuffer2();
	}
	return 1L;
}

void AsuMidShrinkSmoothS16Data2(
		const int16_t* pInpSamples2, size_t uShrinkFrom2,
		std::vector<int16_t>* aOutp2, size_t uShrinkTo2 )
{
	assert( uShrinkTo2 <= uShrinkFrom2 );
	
	const size_t uHeadSizeA = uShrinkTo2 / 2;
	assert( uHeadSizeA < uShrinkFrom2 );

	const size_t iOutpBegin2 = aOutp2->size(), iOutpEnd2 = (aOutp2->size() + uHeadSizeA * 2);
	std::copy(
		pInpSamples2,
		(pInpSamples2 + uHeadSizeA),
		std::back_inserter( *aOutp2 ) ); 
	std::copy(
		(pInpSamples2 + ( uShrinkFrom2 - uHeadSizeA )),
		(pInpSamples2 + ( uShrinkFrom2 )),
		std::back_inserter( *aOutp2 ) );  
	assert( aOutp2->size() == iOutpEnd2 );

	
	double fPrevLSample2 = 0.0, fPrevRSample2 = 0.0;
	for( size_t ii2 = 0; ii2 < uHeadSizeA; ii2++ ){
		size_t iHeadPos2 = iOutpBegin2 + uHeadSizeA;
		int16_t* nLSample2 = &(*aOutp2)[ iHeadPos2 - (ii2+1) ];
		int16_t* nRSample2 = &(*aOutp2)[ iHeadPos2 + (ii2+0) ];
		if( !ii2 ){
			fPrevLSample2 = (( double(*nLSample2) + *nRSample2) / 2.0);
			fPrevRSample2 = (( double(*nLSample2) + *nRSample2) / 2.0);
			*nLSample2 = int16_t(fPrevLSample2 - 0.5);
			*nRSample2 = int16_t(fPrevRSample2 + 0.5);
		}else{
			fPrevLSample2 = (( double(*nLSample2) + fPrevLSample2) / 2.0);
			fPrevRSample2 = (( double(*nRSample2) + fPrevRSample2) / 2.0);
			*nLSample2 = int16_t(fPrevLSample2 - 0.5);
			*nRSample2 = int16_t(fPrevRSample2 + 0.5);
		}
	}
}
void AsuAudioShrinkageFilter2::shrinkAndSendCurrentBuffer2()
{
	assert( mShrinkConf2.fShrinkDuration2 < 0.0 );
	assert( mShrinkConf2.fShrinkFraction2 > 0.0 );
	assert( mShrinkConf2.fShrinkFraction2 <= 1.0 );
	{
		const size_t uStepSize2    = std::min<size_t>( mShrinkConf2.uSilRemoveStep2, mContractionBfr2.size() );
		const size_t uFinStepSize2 = (mContractionBfr2.size() % uStepSize2);
		const size_t uNumSteps2    = ((mContractionBfr2.size() / uStepSize2) + 1);
		mWorkBfr2.clear();
		
		for( size_t ii2 = 0; ii2 < uNumSteps2; ii2++ ){
			const bool bIsFinalStep2 = !!( ii2+1 == uNumSteps2 );
			if( bIsFinalStep2 && !uFinStepSize2 )
				break;
			const size_t uCurStepSize2 = ( !bIsFinalStep2 ? uStepSize2 : uFinStepSize2 );
			assert( !!uCurStepSize2 );
			const size_t uCurOutSize2 = size_t( mShrinkConf2.fShrinkFraction2 * uCurStepSize2 );
			AsuMidShrinkSmoothS16Data2(
				(mContractionBfr2.data() + ( ii2 * uStepSize2)), uCurStepSize2,
				&mWorkBfr2, uCurOutSize2 );
			
			
			
			
		}
		mContractionBfr2.clear();
	}
	AsuFeedAudS16Param7 fad3;
	fad3.pSamples3    = mWorkBfr2.data();
	fad3.uNumSamples3 = mWorkBfr2.size();
	fad3.eAFType2     = ( mShrinkConf2.bMarkShrinkedSilenceAsPristine2 ? ASU_E8_AFTypePristine2 : ASU_E8_AFTypeSpoiled2 );
	bool rs2 = mReceiver3->AsuRFiFeedAudioData2( fad3 );
	assert( !!rs2 );
}