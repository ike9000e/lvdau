#pragma once
#include <string>
#include <vector>
#include <algorithm>    
#include "asu_intrf.hh"

void AsuMidShrinkSmoothS16Data2( const int16_t* pInpSamples2, size_t uShrinkFrom2, std::vector<int16_t>* aOutp2, size_t uShrinkTo2 );

enum AsuAudContractionMode2 : size_t {
	ASU_E9_ContractionByRemove2 = 323977201,
	ASU_E9_ContractionByTimeCompress2,
	ASU_E9_ContractionByLTrim2,
	ASU_E9_ContractionByRTrim2,
	ASU_E9_ContractionByLRTrim2,
	ASU_E9_ContractionByLTruncate2,
	ASU_E9_ContractionByRTruncate2,
	ASU_E9_ContractionByMidTruncate2,
};
enum AsuAudPartitionSelect2 {
	ASU_E10_SelectSpoiledPart2 = 987635501,
	ASU_E10_SelectPristinePart2,
	ASU_E10_SelectBothParts2,
};
struct AsuAudShrinkageDef7 {
	AsuAudContractionMode2  eASMethod2 = ASU_E9_ContractionByRemove2;
	AsuAudPartitionSelect2  eAPSelect2 = ASU_E10_SelectSpoiledPart2;
	double                  fShrinkFraction2 = -1.0;
	double                  fShrinkDuration2 = -1.0;
	size_t                  uMinWorksetSize2 = 65536;
	size_t                  uSilRemoveStep2  = 32768;
	bool                    bMarkShrinkedSilenceAsPristine2 = 0L;
};

struct AsuAudioShrinkageFilter2 : AsuAudioFilterBase2
{
	explicit  AsuAudioShrinkageFilter2( const AsuAudShrinkageDef7& inp );
	;         AsuAudioShrinkageFilter2() = delete;
	auto      AsuAFiGetName2()const -> std::string override {return "Audio_Shrinkage_R1";};
	void      AsuAFiSetFrequency2( size_t inp )override {mFreq2 = inp;}
	void      AsuAFiSetAudioReceiver2( AsuReceiverFilterBase2* inp )override {mReceiver3 = inp;}
	bool      AsuRFiFeedAudioData2( const AsuFeedAudS16Param7& inp )override;
	bool      AsuAFiFinalize2()override;
private:
	bool      isAudioFeedProcessed2( AsuAudFeedType2 )const;
	void      shrinkAndSendCurrentBuffer2();
private:
	AsuAudShrinkageDef7       mShrinkConf2;
	size_t                    mFreq2     = 0;
	AsuReceiverFilterBase2*   mReceiver3 = nullptr;
	std::vector<int16_t>      mContractionBfr2, mWorkBfr2;
};