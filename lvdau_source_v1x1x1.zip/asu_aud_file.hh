#pragma once
#include <cstdio>  
#include <cinttypes>  
#include <string>
#include <vector>
#include <functional>   
#include "asu_intrf.hh"

struct AsuWaveInfo2;  struct AsuWaveSampledData2; struct AsuFrameDump2;
struct AsuReworkWSParams7;

auto        AsuReworkWaveStream2( const AsuReworkWSParams7& inp ) -> DfhQuad2<bool,std::string>;
bool        AsuWaveShowInfo2( const AsuWaveInfo2& wi2, const char* flags2 );
void        AsuUnitTests2();

auto        AsuWaveIsSupported2( const AsuWaveInfo2& inp, const char* flags2 ) -> DfhQuad2<bool,std::string>;
double      AsuWaveGetSampledDataLenInSeconds2( const AsuWaveSampledData2& sSampleDt2, const AsuWaveFmtDesc2& sDFmtDesc2 );
size_t      AsuWaveDecodeFrameBufferToS16Mono2( const void* data2, size_t uDataLenInBytes3, size_t uBitsPerSample2, size_t uNumChannels2, const std::function<void(const AsuFrameDump2&)>* calbFrameDump3, int16_t* pOutFrameBfr2, size_t uOutBfrSize2 );
int16_t     AsuWaveDecodeFrameBytesToS16Mono2( const void* data2, size_t uLenInBytes2, size_t uBitsPerSample2, size_t uNumChannels2, const std::function<void(const AsuFrameDump2&)>* calbFrameDump2 );
auto        AsuWaveDecodeFormatDescChunk3( const void* data2, size_t num2 ) -> DfhQuad2<bool,AsuWaveFmtDesc2,std::string>;
auto        AsuWaveProcessSampledDataStream2( std::FILE* stream3, const AsuWaveFmtDesc2& sFd2, AsuAudioFilterBase2* pAudFilter3, uint64_t uMaxReadOrUntillEof2, const AsuRWCapacityBuffer6* cBfr3 ) -> DfhQuad2<bool,std::string,uint64_t>;

struct AsuReworkWSCalbParams6{
	const AsuWaveInfo2* pWaveInfo2 = nullptr;
};
using AsuCalbOnFmtDesc2_t = std::function<bool( const AsuReworkWSCalbParams6& )>;

struct AsuReworkWSParams7 {
	std::FILE*                stream2             = nullptr;
	AsuAudioFilterBase2*      pAudFilter4         = nullptr;
	AsuWriteOutStreamBase2*   pAudOutStream2      = nullptr;
	uint64_t                  uStrideBufferSize2  = 65536;
	bool                      bDiskFileMode2      = 0L;
	bool                      bDryRunMode2        = 0L;
	uint64_t                  uNumSamplesShow3    = 0;
	AsuCalbOnFmtDesc2_t       calbOnMoreWaveInfo2 = nullptr;
};

struct AsuWaveInfo2 {
	uint64_t    uFileSize2 = 0;
	std::string srMessage2;
	bool        bWaveRecognized2 = 0L;
	std::vector<AsuWaveFmtDesc2> aFmtDescChunks2;
	std::vector<AsuWaveSampledData2> aSampledDataChunks2;
	
	uint64_t    uTotalSampledDataSize2 = 0;  
	uint64_t    uTotalNumFrames2 = 0;
	double      fTotalLenInSeconds2 = 0.0;
	bool        bUniformFmtDescFormat2 = 0L;
	uint32_t    uNumChunks2 = 0;
	uint32_t    uNumUnrecognizedChunks2 = 0;
	std::string srAllChunkNames2;
	uint64_t    uLastChunkFileOffset2 = 0;
	
	static auto makeMsg2( const char* inp ) -> AsuWaveInfo2;
	auto        getFmtForSampledDataIndex2( size_t index2 )const -> const AsuWaveFmtDesc2&;
};


struct AsuWaveSampledData2 {
	uint64_t uDataOffsetInFile2 = 0;  
	uint64_t uSampledDataSize2 = 0;   
	struct {
		double   fLenInSeconds3 = 0.0;
		uint64_t uNumFrames2 = 0;
		bool     bHasPaddingByte2 = 0L;
	}sCalculated4;
	explicit  operator bool()const {return !!this->uSampledDataSize2;}
	bool      isValidSampledData2()const;
};

struct AsuFrameDump2 {
	int16_t         nAvgSample2;
	const int16_t*  pFrameSamples2;
	size_t          uNumChannels3;
	size_t          uNumBitsPerChan2;
	const uint8_t*  pFrameBytes2;
};
