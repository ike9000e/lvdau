#include "asu_aud_file.hh"
#include <cstdlib>  
#include <cassert>  
#include <limits>  
#include <cstring> 
#include <algorithm>
#include "dfh_crt_fix.hh"
#include "dfh_core.hh"
#include "dfh_cma_average.hh"

enum : size_t {

	
	
	
	
	
	ASU_E2_WaveMaxSupportedNumChannels2 = 256,
	ASU_E2_WaveMaxSupportedFrequency2 = 384000, 
};
enum : size_t {
	ASU_E3_WaveDataFmtDescChunkSize2 = 24,
	ASU_E3_WaveOffsetFrequency2 = 12,
	ASU_E3_WaveOffsetNumChannels2 = 10,
	ASU_E3_WaveOffsetAudFormat2 = 8,
	ASU_E3_WaveOffsetBitsPerSample2 = 22,
};
enum : size_t {
	ASU_E4_WaveSampledDataChunkHdrSize2 = 8,
	ASU_E4_WaveSampledDataOffsetToSize2 = 4,
};

AsuWaveInfo2
AsuWaveInfo2::makeMsg2( const char* inp )
{
	assert( inp );
	AsuWaveInfo2 outp;
	outp.srMessage2 = inp;
	return outp;
}

const AsuWaveFmtDesc2& AsuWaveInfo2::getFmtForSampledDataIndex2( size_t index2 )const
{
	assert( !aFmtDescChunks2.empty() );
	index2 = std::min<size_t>( (aFmtDescChunks2.size() - 1), index2 );
	return aFmtDescChunks2[index2];
}
bool AsuWaveFmtDesc2::isSameFormat2( const AsuWaveFmtDesc2& otherr )const
{
	return (
		this->uFrequency2 == otherr.uFrequency2 &&
		this->uNumChannels2 == otherr.uNumChannels2 &&
		this->uAudioFormat2 == otherr.uAudioFormat2 &&
		this->uBitsPerSample2 == otherr.uBitsPerSample2 &&
		1);
}
bool AsuWaveShowInfo2( const AsuWaveInfo2& wi2, const char* flags2 )
{
	flags2 = ( flags2 ? flags2 : "");
	
	
	const auto sIsSupported = AsuWaveIsSupported2(wi2,"");

	const std::string tabs2 = "\x20\x20\x20";
	DfhPf2(1,"{\n",{});
	DfhPf2(1,"%s""Is recognized       : [%s]\n", { tabs2.c_str(), ( !!*AsuWaveIsSupported2(wi2,"r") ? "Yes" : "No"),});
	DfhPf2(1,"%s""Is data valid       : [%s]\n", { tabs2.c_str(), ( !!*AsuWaveIsSupported2(wi2,"c") ? "Yes" : "No"),});
	DfhPf2(1,"%s""Is supported format : [%s]\n", { tabs2.c_str(), ( !!*sIsSupported ? "Yes" : "No"),} );
	DfhPf2(1,"%s""Message #1          : [%s]\n", { tabs2.c_str(), (!wi2.srMessage2.empty() ? wi2.srMessage2.c_str() : "-none-"),});
	DfhPf2(1,"%s""Message #2          : [%s]\n", { tabs2.c_str(), (!sIsSupported.second.empty() ? sIsSupported.second.c_str() : "-none-"),});
	DfhPf2(1,"%s""File size (stored)  : %s B (0x%s)\n", { tabs2.c_str(), std::to_string(wi2.uFileSize2).c_str(), DfhConvU64ToStr2(wi2.uFileSize2,16,0,"X").c_str(),} );
	DfhPf2(1,"%s""Total #of chunks    : %s (Unknown therein: %s)\n", { tabs2.c_str(), std::to_string(wi2.uNumChunks2).c_str(), std::to_string(wi2.uNumUnrecognizedChunks2).c_str(),} );
	DfhPf2(1,"%s""Chunk names         : [%s]\n", { tabs2.c_str(), wi2.srAllChunkNames2.c_str(),} );
	DfhPf2(1,"%s""Offset of last      : %s B\n", { tabs2.c_str(), std::to_string(wi2.uLastChunkFileOffset2).c_str(),} );
	DfhPf2(1,"%s""Total data size     : %s B (0x%s)\n", { tabs2.c_str(), std::to_string(wi2.uTotalSampledDataSize2).c_str(), DfhConvU64ToStr2(wi2.uTotalSampledDataSize2,16,0,"X").c_str(),} );
	DfhPf2(1,"%s""Total #frames       : %s\n", { tabs2.c_str(), std::to_string(wi2.uTotalNumFrames2).c_str(),} );
	DfhPf2(1,"%s""#of Format-Desc-s   : %s (Uniform: %s)\n", { tabs2.c_str(), std::to_string(wi2.aFmtDescChunks2.size()).c_str(), (wi2.bUniformFmtDescFormat2 ? "Yes" : "No"),} );
	DfhPf2(1,"%s""Total duration      : %s seconds (%s)\n", { tabs2.c_str(), DfhConvFloatToStr2( wi2.fTotalLenInSeconds2, 0, 9,"").c_str(), DfhConvSecondsToHMSString2(wi2.fTotalLenInSeconds2,"z").c_str(),} );
	const std::string tabs3 = "\x20\x20\x20\x20\x20\x20";
	{
		AsuWaveFmtDesc2 sFd3;
		DfhPf2(1,"\n",{});
		DfhPf2(1,"%s""First Data Format Description chunk ('fmt'):\n", { tabs2.c_str(),} );
		const AsuWaveFmtDesc2 dflt2;
		sFd3 = ( !wi2.aFmtDescChunks2.empty() ? wi2.aFmtDescChunks2[0] : dflt2 );
		DfhPf2(1,"%s- Frequency       : %s Hz\n", { tabs3.c_str(), std::to_string(sFd3.uFrequency2).c_str(),} );
		DfhPf2(1,"%s- Num channels    : %s\n", { tabs3.c_str(), std::to_string(sFd3.uNumChannels2).c_str(),} );
		DfhPf2(1,"%s- Bits per sample : %u (bytes: %u)\n", { tabs3.c_str(), sFd3.uBitsPerSample2, (sFd3.uBitsPerSample2/8),} );
		DfhPf2(1,"%s- Audio format    : %s \x22%s\x22\n", { tabs3.c_str(), std::to_string(sFd3.uAudioFormat2).c_str(), sFd3.srAudioFormatName2.c_str(),} );
		DfhPf2(1,"%s- Bytes/sec       : %s (in regard to all %u channels)\n", { tabs3.c_str(), std::to_string(sFd3.sCalculated2.uBytesPerSecond2).c_str(), sFd3.uNumChannels2,} );
	}{
		DfhPf2(1,"\n",{});
		DfhPf2(1,"%s""First Sampled Data chunk ('data'):\n", { tabs2.c_str(),} );
		const AsuWaveSampledData2 dflt3;
		const AsuWaveSampledData2& sSd2 = ( !wi2.aSampledDataChunks2.empty() ? wi2.aSampledDataChunks2[0] : dflt3 );
		DfhPf2(1,"%s- Offset In File : %s B\n", { tabs3.c_str(), std::to_string(sSd2.uDataOffsetInFile2).c_str(),} );
		DfhPf2(1,"%s- Size           : %s B (0x%s)\n", { tabs3.c_str(), std::to_string(sSd2.uSampledDataSize2).c_str(), DfhConvU64ToStr2(sSd2.uSampledDataSize2,16,0,"X").c_str(),} );
		DfhPf2(1,"%s- Duration       : %s seconds (%s)\n", { tabs3.c_str(), (DfhConvFloatToStr2( sSd2.sCalculated4.fLenInSeconds3, 0, 9,"").c_str()), DfhConvSecondsToHMSString2(sSd2.sCalculated4.fLenInSeconds3,"z").c_str(),} );
		DfhPf2(1,"%s- Num Frames     : %s\n", { tabs3.c_str(), std::to_string(sSd2.sCalculated4.uNumFrames2).c_str(),} );
	}
	DfhPf2(1,"}\n",{});
	return 1L;
}

DfhQuad2<bool,AsuWaveFmtDesc2,std::string>
AsuWaveDecodeFormatDescChunk3( const void* data2, size_t num2 )
{
	assert( num2 >= ASU_E3_WaveDataFmtDescChunkSize2 );
	const uint8_t* bfr3 = reinterpret_cast<const uint8_t*>( data2 );

	AsuWaveFmtDesc2 ou2;
	ou2.uFrequency2     = AsuUnpackU32LEBytes2( &bfr3[ASU_E3_WaveOffsetFrequency2] );
	ou2.uNumChannels2   = AsuUnpackU16LEBytes2( &bfr3[ASU_E3_WaveOffsetNumChannels2] );
	ou2.uAudioFormat2   = AsuUnpackU16LEBytes2( &bfr3[ASU_E3_WaveOffsetAudFormat2] );
	ou2.uBitsPerSample2 = AsuUnpackU16LEBytes2( &bfr3[ASU_E3_WaveOffsetBitsPerSample2] );
	ou2.srAudioFormatName2 = (
		ou2.uAudioFormat2 == ASU_E5_WaveAudioFormatPCMInteger2   ? "ASU_AF_PCM_Integer" : (
		ou2.uAudioFormat2 == ASU_E5_WaveAudioFormatIEEE754Float2 ? "ASU_AF_IEEE_754_Float" :
		AsuSf2("ASU_AF_Unknown(%s)", std::to_string(ou2.uAudioFormat2).c_str() ).c_str()));

	if( !ou2.uFrequency2 ){
		return {0L,{},"Invalid frequency value (zero) [FN2EVM]",};
	}
	if( !ou2.uNumChannels2 ){
		return {0L,{},"Invalid number of channels value (zero) [078wtz]",};
	}
	if( !ou2.uBitsPerSample2 ){
		return {0L,{}, "Invalid bits-per-sample value (zero) [qNXjE5]",};
	}
	ou2.sCalculated2.uBytesPerSecond2 = (
			ou2.uFrequency2 * ou2.uNumChannels2 * (ou2.uBitsPerSample2 / 8) );
	ou2.sCalculated2.uBytesPerFrame2 = ( (ou2.uBitsPerSample2/8) * ou2.uNumChannels2 );
	return {1L,ou2,"",};
}
DfhQuad2<bool,AsuWaveSampledData2,std::string>
AsuWaveDecodeSampleDataChunk3( const void* data2, size_t num2,
		const AsuWaveFmtDesc2& sFd2, uint64_t uChunkStartOffset3 )
{
	assert( num2 >= 8 );
	assert( !!sFd2.uBitsPerSample2 && !(sFd2.uBitsPerSample2 % 8) );
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );

	AsuWaveSampledData2 sSd3;
	sSd3.uSampledDataSize2  = AsuUnpackU32LEBytes2( &data3[ASU_E4_WaveSampledDataOffsetToSize2] );
	sSd3.uDataOffsetInFile2 = uChunkStartOffset3 + ASU_E4_WaveSampledDataChunkHdrSize2;
	if( !sSd3.uSampledDataSize2 ){
		return {0L,{},"Size of sampled data is zero [S0TgQ6]",};
	}
	sSd3.sCalculated4.fLenInSeconds3   = AsuWaveGetSampledDataLenInSeconds2( sSd3, sFd2 );
	sSd3.sCalculated4.uNumFrames2      = ( sSd3.uSampledDataSize2 / ((sFd2.uBitsPerSample2/8) * sFd2.uNumChannels2));
	sSd3.sCalculated4.bHasPaddingByte2 = ( (sSd3.uSampledDataSize2 % 2) ? 1L : 0L );
	if( !sSd3.sCalculated4.uNumFrames2 ){
		return {0L,{},AsuSf2("Size of sampled data %s is too small. It's smaller than required for a single frame [ZGe4py]",
				std::to_string(sSd3.uSampledDataSize2).c_str() ),};
	}
	assert( !!sSd3.isValidSampledData2() );
	return {1L,sSd3,"",};
}
bool AsuWaveSampledData2::isValidSampledData2()const
{
	return (
		!!this->uSampledDataSize2 &&
		!!this->sCalculated4.fLenInSeconds3 &&
		!!this->sCalculated4.uNumFrames2 &&
		1);
}

double AsuWaveGetSampledDataLenInSeconds2( const AsuWaveSampledData2& sSampleDt2,
			const AsuWaveFmtDesc2& sDFmtDesc2 )
{
	assert( !!sDFmtDesc2.sCalculated2.uBytesPerSecond2 );
	double fDurationInSeconds2 = (
		double(sSampleDt2.uSampledDataSize2) /
			double(sDFmtDesc2.sCalculated2.uBytesPerSecond2) );
	return fDurationInSeconds2;
}

void AsuUnitTests2()
{
	{
		int16_t val2 = AsuConvU08ToS16LLWise2( 0x00 );
		int16_t val3 = AsuConvU08ToS16LLWise2( 0xFF );
		assert( val2 == std::numeric_limits<int16_t>::min() );
		assert( val3 == std::numeric_limits<int16_t>::max() );
	}{
		int16_t val4 = AsuConvS32ToS16LLWise2( std::numeric_limits<int32_t>::min() );
		int16_t val5 = AsuConvS32ToS16LLWise2( std::numeric_limits<int32_t>::max() );
		assert( val4 == std::numeric_limits<int16_t>::min() );
		assert( val5 == std::numeric_limits<int16_t>::max() );
	}{
		{
			uint8_t bytes2[] = { 0xFF,0xFF,0xFF,0x7F,};
			uint32_t val2 = AsuUnpackU32LEBytes2( bytes2 );
			assert( val2 == 0x7FFFFFFF );
		}{
			uint8_t bytes2[] = { 0x7F,0xFF,0xFF,0xFF,};
			uint32_t val2 = AsuUnpackU32LEBytes2( bytes2 );
			assert( val2 == 0xFFFFFF7F );
		}{
			uint8_t bytes2[] = { 0xFF,0xFF,0xFF,0xFF,};
			uint32_t val2 = AsuUnpackU32LEBytes2( bytes2 );
			assert( val2 == std::numeric_limits<uint32_t>::max() );
		}
	}{
		{
			uint8_t bytes4[] = { 0xFF,0x7F,};
			int16_t iVal3 = AsuUnpackS16LEBytes2( bytes4 );
			assert( iVal3 == std::numeric_limits<int16_t>::max() );
			assert( iVal3 == 32767 );
		}{
			uint8_t bytes4[] = { 0x00,0x80,};
			int16_t iVal3 = AsuUnpackS16LEBytes2( bytes4 );
			assert( iVal3 == std::numeric_limits<int16_t>::min() );
			assert( iVal3 == -32768 );
		}{
			uint8_t bytes4[] = { 0xFF,0xFF,};
			int16_t iVal3 = AsuUnpackS16LEBytes2( bytes4 );
			assert( iVal3 == -1 );
		}{
			uint8_t bytes4[] = { 0xFE,0xFF,};
			int16_t iVal3 = AsuUnpackS16LEBytes2( bytes4 );
			assert( iVal3 == -2 );
		}
	}
}
DfhQuad2<bool,std::string>
AsuWaveIsSupportedFormatDescType2( const AsuWaveFmtDesc2& inp, const char* flags2_u_ )
{
	std::string msg2;
	if( inp.uAudioFormat2 != ASU_E5_WaveAudioFormatPCMInteger2 ){
		msg2 += AsuSf2("Unsupprted auido format (%s). ",
			std::to_string(inp.uAudioFormat2).c_str() );
	}
	if( !AsuAnyU32u2( inp.uBitsPerSample2, {8,16,}) ){
		msg2 += AsuSf2("Unsupprted bits-per-sample (%s). ",
			std::to_string(inp.uBitsPerSample2).c_str());
	}
	if( inp.uNumChannels2 > ASU_E2_WaveMaxSupportedNumChannels2 ){
		msg2 += AsuSf2("Unsupprted number of channles (%s). ",
			std::to_string(inp.uNumChannels2).c_str() );
	}
	if( inp.uFrequency2 > ASU_E2_WaveMaxSupportedFrequency2 ){
		msg2 += AsuSf2("Unsupprted frequency (%s). ",
			std::to_string(inp.uFrequency2).c_str() );
	}
	msg2 += ( *msg2.c_str() ? "[5MW3iN]": "");
	return { bool( !*msg2.c_str() ? 1L : 0L), msg2,};
}
DfhQuad2<bool,std::string>
AsuWaveIsSupported2( const AsuWaveInfo2& inp, const char* flags2 )
{
	bool bCheckValidContents2 = 1L, bCheckIsRecognized2 = 1L;
	bool bCheckAllFmtDesc2 = 1L;
	if( flags2 && !!*flags2 ){
		bCheckValidContents2 = !!std::strchr( flags2, 'c');
		bCheckIsRecognized2 = !!std::strchr( flags2, 'r');
		bCheckAllFmtDesc2 = !!std::strchr( flags2, 'f');
	}
	if( bCheckValidContents2 ){
		if( !inp.uFileSize2 || inp.aFmtDescChunks2.empty() ||
			inp.aSampledDataChunks2.empty()
		){
			return {0L,"Wave file structure is invalid [5Vr4rM]",};
		}
	}
	if( bCheckIsRecognized2 ){
		if( !inp.bWaveRecognized2 ){
			return {0L,"Not recognized as Wave file [K6jfPV]",};
		}
	}
	if( bCheckAllFmtDesc2 ){
		assert( !inp.aFmtDescChunks2.empty() );
		const auto& ls2 = inp.aFmtDescChunks2;
		size_t iChk2 = 0;
		for( auto ir2 = ls2.begin(); ir2 != ls2.end(); ++ir2, ++iChk2 ){
			auto rs2 = AsuWaveIsSupportedFormatDescType2( *ir2, "" );
			if( !*rs2 ){
				return {0L,AsuSf2("[%s] in fmt-desc chunk #%d [8LMzcj]",
					rs2.second.c_str(), int(iChk2)),};
			}
		}
	}
	return {1L,"",};
}

size_t AsuWaveDecodeFrameBufferToS16Mono2(
			const void* data2, size_t uDataLenInBytes3,
			size_t uBitsPerSample2, size_t uNumChannels2,
			const std::function<void(const AsuFrameDump2&)>* calbFrameDump3,
			int16_t* pOutFrameBfr2, size_t uOutBfrSize2 )
{
	assert( !!data2 );
	assert( !!uDataLenInBytes3 );
	assert( !!pOutFrameBfr2 );
	assert( !!uOutBfrSize2 );
	assert( !!uBitsPerSample2 );
	assert( !( uBitsPerSample2 % 8 ) );
	assert( !!uNumChannels2 );
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	const size_t uFrameBtSize2    = ( (uBitsPerSample2/8) * uNumChannels2 );
	const size_t uNumFramesInBuf2 = uDataLenInBytes3 / uFrameBtSize2;
	assert( !!uNumFramesInBuf2 );
	assert( uNumFramesInBuf2 <= uOutBfrSize2 );

	for( size_t ii2 = 0; ii2 < uNumFramesInBuf2; ii2++ ){
		const uint8_t* pFrameData2 = &data3[ ii2 * uFrameBtSize2 ];
		int16_t sample2 = AsuWaveDecodeFrameBytesToS16Mono2( pFrameData2,
				uFrameBtSize2, uBitsPerSample2, uNumChannels2, calbFrameDump3 );
		pOutFrameBfr2[ii2] = sample2;
	}
	return uNumFramesInBuf2;
}

int16_t AsuWaveDecodeFrameBytesToS16Mono2(
			const void* data2, size_t uDataLenInBytes2,
			size_t uBitsPerSample2, size_t uNumChannels2,
			const std::function<void(const AsuFrameDump2&)>* calbFrameDump2 )
{
	const uint8_t* data3 = reinterpret_cast<const uint8_t*>( data2 );
	assert( uBitsPerSample2 >= 8 && uBitsPerSample2 <= 32 );
	assert( !(uBitsPerSample2 % 8) );
	const size_t uNumBytesPChan2 = ( (uBitsPerSample2 / 8) * 1 );
	const size_t uNumBytesPFrame2 = ( (uBitsPerSample2 / 8) * uNumChannels2 );
	assert( uNumBytesPFrame2 <= uDataLenInBytes2 );
	std::vector<int16_t> aFrameSamples2;
	DfhCMAAverage2<int64_t> avg2;
	for( size_t iC2 = 0; iC2 < uNumChannels2; iC2++ ){
		int16_t sample4;
		if( uNumBytesPChan2 == 1 ){
			uint8_t val2 = data3[iC2];
			sample4 = AsuConvU08ToS16LLWise2( val2 );
			
			avg2.update2( sample4 );
		}else if( uNumBytesPChan2 == 2 ){
			const uint8_t* bytes2 = &data3[iC2 * uNumBytesPChan2];
			sample4 = AsuUnpackS16LEBytes2( bytes2 );
			
			
			avg2.update2( sample4 );
		}else if( uNumBytesPChan2 == 3 ){
			assert(!"LVDAU: 24-bit mode not implemented [tv3uo5]");
		}else if( uNumBytesPChan2 == 4 ){
			assert(!"LVDAU: 32-bit mode not implemented [rKrONs]");
		}else{
			assert(!"LVDAU: Bad branching [pOTeA3]");
		}
		if( calbFrameDump2 ){
			aFrameSamples2.push_back( sample4 );
		}
	}
	int16_t nAvg2 = int16_t(avg2.getAvg());
	if( calbFrameDump2 ){
		assert( !aFrameSamples2.empty() );
		assert( aFrameSamples2.size() == uNumChannels2 );
		AsuFrameDump2 fdm2;
		fdm2.nAvgSample2      = nAvg2;
		fdm2.pFrameSamples2   = aFrameSamples2.data();
		fdm2.uNumChannels3    = uNumChannels2;
		fdm2.pFrameBytes2     = data3;
		fdm2.uNumBitsPerChan2 = uBitsPerSample2;
		(*calbFrameDump2)( fdm2 );
	}
	return nAvg2;
}


DfhQuad2<bool,std::string>
AsuReworkWaveStream2( const AsuReworkWSParams7& inp )
{
	assert( !!inp.stream2 );
	assert( !!inp.pAudFilter4 );
	assert( !!inp.pAudOutStream2 );
	assert( !!inp.uStrideBufferSize2 );
	assert( !inp.uNumSamplesShow3 );

	

	AsuRWCapacityBuffer6 cBfr4;
	cBfr4.AsuCBiReserve2( inp.uStrideBufferSize2 );
	

	auto lmbSkipStreamBytes2 = [&cBfr4,&inp]( uint64_t uNumSkip2 ){
		bool bForceFreadOverFseek2 = 0L;
		#ifdef __MINGW32__
			bForceFreadOverFseek2 = 1L;
		#endif
		assert( uNumSkip2 <= size_t( std::numeric_limits<long>::max() ) );
		if( inp.bDiskFileMode2 || !bForceFreadOverFseek2 ){
			std::fseek( inp.stream2, long(uNumSkip2), SEEK_CUR );
		}else{
			
			
			assert( !!cBfr4.AsuCBiCapacity2() );
			cBfr4.AsuCBiResize2( cBfr4.AsuCBiCapacity2() );
			for( size_t ii2 = (uNumSkip2 / cBfr4.AsuCBiGetSize2()); ii2; ii2-- ){
				std::fread( cBfr4.AsuCBiGetData2(), 1, cBfr4.AsuCBiGetSize2(), inp.stream2 );
			}
			std::fread( cBfr4.AsuCBiGetData2(), 1, (uNumSkip2 % cBfr4.AsuCBiGetSize2()), inp.stream2 );
		}
	};
	bool bHaveMasterChunk2 = 0L;
	AsuWaveInfo2 wi2;
	for( ; ; ){   
		if( !bHaveMasterChunk2 ){
			uint8_t bfr12Ba[12];
			size_t readd2 = std::fread( bfr12Ba, 1, sizeof(bfr12Ba), inp.stream2 );
			if( readd2 != sizeof(bfr12Ba) ){
				return {0L,AsuSf2("Failed reading %d bytes at stream position 0 [80Tx5f8]", int(sizeof(bfr12Ba)) ),};
			}
			if( !!std::memcmp( &bfr12Ba[0], "RIFF", 4 ) ){
				return {0L,"Stream not recognized as RIFF(WAVE) [iAIfBeA]",};
			}
			DfhPf2(12,"LVDAU: Got WAVE-RIFF\n",{});

			wi2.uFileSize2 = AsuUnpackU32LEBytes2( &bfr12Ba[4] );
			if( !wi2.uFileSize2 ){
				return {0L,AsuSf2("Unexpected, stored file size (zero) [jIJR8p]"),};
			}
			if( !!std::memcmp( &bfr12Ba[8], "WAVE", 4 ) ){
				return {0L,"Stream not recognized as WAVE [Fsoxzw]",};
			}
			wi2.bWaveRecognized2 = 1L;
			wi2.uNumChunks2 = 1;
			bHaveMasterChunk2 = 1L;
		}else{
			uint8_t bfr4Ba[4];
			const long nFileOffsetAtChunk2 = std::ftell( inp.stream2 );
			DfhPf2(12,"LVDAU: Current stream|file offset: %s\n",{
				std::to_string(nFileOffsetAtChunk2).c_str(),} );
			const size_t readd3 = std::fread( bfr4Ba, 1, sizeof(bfr4Ba), inp.stream2 );
			if( readd3 != sizeof(bfr4Ba) ){
				if( !!std::feof( inp.stream2 ) ){
					DfhPf2(8,"LVDAU: Reached end of stream. Last chunk offset: %s\n",{
						std::to_string(wi2.uLastChunkFileOffset2).c_str(),} );
					if( !inp.pAudFilter4->AsuAFiFinalize2() ){
						return {0L,AsuSf2("LVDAU: ERROR: Audio filter '%s' failed finalize [kvG7p5V]", inp.pAudFilter4->AsuAFiGetName2().c_str() ),};
					}
					
					return {1L,"",};
				}
				return {0L,AsuSf2("Failed reading %d bytes at stream position %s [72t4dhZ]",
					int(sizeof(bfr4Ba)), std::to_string(nFileOffsetAtChunk2).c_str() ),};
			}
			wi2.uLastChunkFileOffset2 = nFileOffsetAtChunk2;
			wi2.srAllChunkNames2 += DfhSf2("%s,", { AsuStrReplProvideSafeChars2(bfr4Ba,4).c_str(),});
			DfhPf2(8,"LVDAU: Chunk #%s [%s], File offset: %s\n",{
					std::to_string(wi2.uNumChunks2).c_str(),
					AsuStrReplProvideSafeChars2(bfr4Ba,4).c_str(), std::to_string(nFileOffsetAtChunk2).c_str(),} );

			if( !std::memcmp( bfr4Ba, "fmt\x20", 4 ) ){
				if( wi2.aFmtDescChunks2.empty() ){
					wi2.bUniformFmtDescFormat2 = 1L;
				}
				uint8_t bfr24Ba[ASU_E3_WaveDataFmtDescChunkSize2];   
				std::memcpy( bfr24Ba, bfr4Ba, 4 );
				size_t readd4 = std::fread( &bfr24Ba[4], 1, (sizeof(bfr24Ba)-4), inp.stream2 );
				if( readd4 != (sizeof(bfr24Ba)-4) ){
					return {0L,AsuSf2("Failed reading %d bytes at stream position %s [jVYQXo]",
						int((sizeof(bfr24Ba)-4)), std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				auto res2 = AsuWaveDecodeFormatDescChunk3( bfr24Ba, sizeof(bfr24Ba) );
				if( !*res2 ){
					return {0L,AsuSf2("Failed decoding format-desc chunk [%s]. Stream position [%s] [fouSwa]",
						res2.third.c_str(), std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				std::for_each( wi2.aFmtDescChunks2.begin(), wi2.aFmtDescChunks2.end(),
					[&]( const AsuWaveFmtDesc2& sFd2 )->void{
						if( !sFd2.isSameFormat2( res2.second ) ){ wi2.bUniformFmtDescFormat2 = 0L;}
				});
				wi2.aFmtDescChunks2.push_back( res2.second ); 

				
				auto res4 = AsuWaveIsSupportedFormatDescType2( res2.second, "" );
				if( !*res4 ){
					return {0L,AsuSf2("[%s] Format-Desc chunk #%s, File pos: %s [Esb2tn]",
						res4.second.c_str(),
						std::to_string(wi2.uNumChunks2).c_str(),
						std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				
				inp.pAudOutStream2->AsuWOiSetWaveFormat2( res2.second );
			}else if( !std::memcmp( bfr4Ba, "data", 4 ) ){
				if( wi2.aFmtDescChunks2.empty() ){
					return {0L,AsuSf2("Sampled data chunk has no prior Format-Desc. File pos: %s [hvWwMt]",
						std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				assert( !!*AsuWaveIsSupported2( wi2, "rf") );
				uint8_t bfr8Ba[8];
				std::memcpy( bfr8Ba, bfr4Ba, 4 );
				size_t readd5 = std::fread( &bfr8Ba[4], 1, 4, inp.stream2 );
				if( readd5 != 4 ){
					return {0L,AsuSf2("Failed reading 4 bytes at stream position %s [apRn0nc]",
						std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				const AsuWaveFmtDesc2& sFd2 = wi2.getFmtForSampledDataIndex2( wi2.aSampledDataChunks2.size() );
				auto rs3 = AsuWaveDecodeSampleDataChunk3( bfr8Ba, sizeof(bfr8Ba), sFd2, wi2.uLastChunkFileOffset2 );
				
				if( !*rs3 ){
					return {0L,AsuSf2("Failed decoding sampled data chunk [%s]. Stream position: %s [mDJQCK]",
						rs3.third.c_str(), std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				const AsuWaveSampledData2& sSd2 = rs3.second;
				assert( !!sSd2.isValidSampledData2() );
				wi2.uTotalSampledDataSize2      += sSd2.uSampledDataSize2;
				wi2.uTotalNumFrames2            += sSd2.sCalculated4.uNumFrames2;
				wi2.fTotalLenInSeconds2         += sSd2.sCalculated4.fLenInSeconds3;
				wi2.aSampledDataChunks2.push_back( sSd2 );
			
				DfhPf2(8,"LVDAU: Sampled data size: %s. Is 0xFFFFFFFF or more: [%s]\n", { std::to_string(sSd2.uSampledDataSize2).c_str(), ((sSd2.uSampledDataSize2 >= 0xFFFFFFFF)?"Yes":"No"),});
				if( inp.calbOnMoreWaveInfo2 ){
					AsuReworkWSCalbParams6 scp2;
					scp2.pWaveInfo2 = &wi2;
					if( !inp.calbOnMoreWaveInfo2( scp2 ) ){
						return {1L,"user_cancel_T93amV",};
					}
				}
				if( !!inp.bDiskFileMode2 || inp.bDryRunMode2 ){
					if( sSd2.uSampledDataSize2 > std::numeric_limits<long>::max() ){
						return {0L,AsuSf2("Sampled data size %s is too big. Chunk index: %s [vaKjO4]",
								std::to_string(sSd2.uSampledDataSize2).c_str(),
								std::to_string(wi2.uNumChunks2).c_str() ),};
					}
				}
				if( !inp.bDryRunMode2 ){
					const uint64_t uDataSizeToRead2 = ( sSd2.uSampledDataSize2 == 0xFFFFFFFF ? uint64_t(-1) : sSd2.uSampledDataSize2 );
					const AsuWaveFmtDesc2& sFd4 = wi2.aFmtDescChunks2.back();
					inp.pAudFilter4->AsuAFiSetFrequency2( sFd4.uFrequency2 );
					auto rs4 = AsuWaveProcessSampledDataStream2( inp.stream2, sFd4,
							inp.pAudFilter4,
							uDataSizeToRead2, &cBfr4 );
					if( !*rs4 ){
						return {0L,AsuSf2("Failed processing sampled data. [%s] Chunk index: %s [gZzexM]",
								rs4.second.c_str(), std::to_string(wi2.uNumChunks2).c_str() ),};
					}
				}else{
					lmbSkipStreamBytes2( sSd2.uSampledDataSize2 );
					if( sSd2.sCalculated4.bHasPaddingByte2 ){
						lmbSkipStreamBytes2( 1 );
					}
				}
			}else{
				
				DfhPf2(8,"LVDAU: Unsupported Wave chunk [%s]\n", { AsuStrReplProvideSafeChars2(bfr4Ba,4).c_str(),} );
				wi2.uNumUnrecognizedChunks2 += 1;
				uint8_t bfrU32u2[4];
				size_t readd7 = std::fread( bfrU32u2, 1, 4, inp.stream2 );
				if( readd7 != 4 ){
					return {0L,AsuSf2("Failed reading 4 bytes at stream position %s [J3pf08]",
						std::to_string(nFileOffsetAtChunk2).c_str() ),};
				}
				const uint32_t uChunkSize3 = AsuUnpackU32LEBytes2( bfrU32u2 );
				DfhPf2(8,"       Size of the unsupported chunk: %s\n", { std::to_string(uChunkSize3).c_str(),} );
				if( uChunkSize3 > uint64_t( std::numeric_limits<long>::max() ) ){
					return {0L,AsuSf2("Chunk size %s is too large [Aa742T]",
							std::to_string( uChunkSize3 ).c_str()),};
				}
				lmbSkipStreamBytes2( uChunkSize3 );
			}
		}
		wi2.uNumChunks2 += 1;
	}
	assert(!"LVDAU: Unreachable code [nkvdGH]");
	return {1L,"",};
}



DfhQuad2<bool,std::string,uint64_t>
AsuWaveProcessSampledDataStream2( std::FILE* stream3,
		const AsuWaveFmtDesc2& sFd2, AsuAudioFilterBase2* pAudFilter5,
		uint64_t uMaxReadOrUntillEof2,
		const AsuRWCapacityBuffer6* cBfr3 )
{
	assert( !!stream3 );
	assert( !!pAudFilter5 );
	assert( !!uMaxReadOrUntillEof2 );
	assert( !!cBfr3 );
	assert( !!sFd2.sCalculated2.uBytesPerFrame2 );
	std::vector<int16_t> aAudS16FrameBfr2;
	{
		size_t uNumFrInBuf2 = cBfr3->AsuCBiCapacity2() / sFd2.sCalculated2.uBytesPerFrame2;
		assert( !!uNumFrInBuf2 );
		aAudS16FrameBfr2.resize( uNumFrInBuf2 );
	}
	uint64_t uCountBytesReadd4 = 0;
	auto rs2 = AsuProcessStandardStream2( stream3,
		sFd2.sCalculated2.uBytesPerFrame2,
		uMaxReadOrUntillEof2, cBfr3,
		[&]( const uint8_t* data2, size_t num2, std::string* err3 )->bool{
			assert( !!num2 && !!data2 && !!err3 );
			assert( !(num2 % sFd2.sCalculated2.uBytesPerFrame2) );
			const size_t uNumFrExpect3 = (num2 / sFd2.sCalculated2.uBytesPerFrame2);
			assert( !!uNumFrExpect3 );

			uCountBytesReadd4 += num2;
			
			
			

			const size_t uNumRet3 = AsuWaveDecodeFrameBufferToS16Mono2(
				data2, num2,
				sFd2.uBitsPerSample2, sFd2.uNumChannels2,
				nullptr,
				aAudS16FrameBfr2.data(), aAudS16FrameBfr2.size() );
			assert( uNumRet3 == uNumFrExpect3 );
			assert( uNumRet3 <= aAudS16FrameBfr2.size() );

			AsuFeedAudS16Param7 fadp4;
			fadp4.pSamples3    = aAudS16FrameBfr2.data();
			fadp4.uNumSamples3 = uNumRet3;
			fadp4.eAFType2     = ASU_E8_AFTypePristine2;

			bool rs2 = pAudFilter5->AsuRFiFeedAudioData2( fadp4 );  
			if( !rs2 ){
				*err3 = AsuSf2("Audio filter '%s' failed. Sampled data bytes read so far: %s [a3eA9X]",
						pAudFilter5->AsuAFiGetName2().c_str(), std::to_string(uCountBytesReadd4).c_str() );
				return 0L;
			}
			return 1L;
	});
	return rs2;
}