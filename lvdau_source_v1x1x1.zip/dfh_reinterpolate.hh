#pragma once

;           constexpr   
double      DfhGetMathPiValue2(){return 3.141592653589793116;}
;           constexpr   
double      DfhGetMathEulerValue2(){return 2.718281828459045235;}
double      DfhMirrorScalarOnPivot2( double inp, double ffPivot );
double      DfhUnitAmplifySineSCurvePart2( double xxx );
double      DfhUnitAmplifySmoothStep2( double xxx );
double      DfhUnitAmplifyCircleNWQuadrant2( double xxx );
double      DfhUnitAmplifyCircleSEQuadrant2( double xxx );
double      DfhUnitAmplifySCurveNWSEQuadrants2( double xxx );
double      DfhUnitAmplifyQuarterSine2( double xxx );
double      DfhUnitAmplifyFlippedQuarterSine2( double xxx );
double      DfhUnitAmplifyXPower2( double xxx, double exp_ );
double      DfhUnitAmplifyFlippedXPower2( double xxx, double exp_ );
double      DfhUnitAmplifySquareRoot2( double xxx );
double      DfhUnitAmplifyNthRoot2( double xxx, double fNthRoot2 );
double      DfhUnitAmplifyFlippedNthRoot2( double xxx, double fNthRoot2 );